# CLARA.js — Laboratórios virtuais de Ciências no navegador

> **Centro de Laboratórios para Aprendizagem e Representação Analítica**
> Plataforma web gratuita de experimentos interativos de Física, Química e Biologia para o ensino médio, com 3D, realidade aumentada, realidade virtual e interação por gestos da mão pela webcam.

🔗 **Site:** https://darlan-ferreira1.github.io/CLARA.js/
🎓 **Contexto:** Trabalho de Conclusão de Curso em Ciência da Computação — Universidade Federal do Ceará (UFC)
🛠️ **Stack:** React 19 · TypeScript · Vite · Three.js · WebXR · MediaPipe · GitHub Actions / GitHub Pages

---

## O problema

Muitas escolas de ensino médio não têm laboratório de Ciências: montar e manter um é caro. As alternativas digitais costumam ter pelo menos um destes problemas:

- exigem hardware específico, como óculos de realidade virtual;
- cobram licença;
- dependem de plataformas fechadas.

Sem experimentação, conteúdos como órbitas atômicas, a geometria de moléculas ou a relação entre pressão e volume de um gás ficam só no quadro e no livro.

## A solução

O **CLARA.js** é um site em que o estudante **manipula o fenômeno** em vez de só ler sobre ele. Basta abrir o endereço: não há instalação, cadastro nem servidor. Funciona no computador e no celular. Quando o aparelho permite, o mesmo experimento também pode ser visto em realidade aumentada (sobre a mesa da sala de aula), em realidade virtual ou controlado com as próprias mãos.

Cada experimento vem com dois textos:

- **Teoria** — o conteúdo explicado para o aluno;
- **Como foi feito** — a documentação técnica de como aquele experimento foi construído.

## Formas de explorar

### 🖼️ Galeria
Todos os experimentos em cartões, com busca e filtro por área. Cada um tem controles de parâmetros (massa, comprimento, ângulo, número atômico…) que mudam a simulação em tempo real.

### 🏛️ Museu Virtual
Um museu 3D percorrido em primeira pessoa: **WASD + mouse** no computador, **joystick na tela** no celular. Cada porta leva à **sala interativa** de um experimento, onde ele aparece em escala ampliada e pode ser ajustado sem sair do ambiente. Na troca de sala, a tela escurece e o conteúdo é trocado dentro da mesma cena 3D, sem recarregar a página.

### 📱 Realidade aumentada
O estudante aponta o celular para o chão ou para uma mesa e vê uma retícula sobre a superfície detectada. Ao tocar na tela, o objeto é posicionado ali (um átomo de Bohr, uma molécula ou uma dupla hélice de DNA). Os gestos na tela controlam o objeto:

- **arrastar** move;
- **pinça** muda o tamanho;
- **girar com dois dedos** gira.

Um painel ⚙ sobreposto à câmera permite mudar os parâmetros do experimento.

### 🥽 Realidade virtual
Funciona em headsets compatíveis com WebXR, também direto do navegador.

### ✋ Interação por gestos (webcam)
Experimentos em que **o corpo do estudante faz parte do experimento**:

- **Você é o Móvel** — a mão vira o objeto de um estudo de cinemática. Os gráficos de posição, velocidade e aceleração são desenhados em tempo real conforme o estudante move a mão diante da câmera.
- **Lei de Boyle com as Mãos** — as duas mãos são as paredes de um recipiente com gás. Ao aproximá-las, o volume diminui e a pressão, medida a partir das colisões das partículas, aumenta.
- **Dissecação Guiada por Gestos** — uma dissecação virtual de anfíbio controlada pelo gesto de pinça.

O rastreamento das mãos roda **no próprio dispositivo**, e nenhuma imagem da câmera é enviada para lugar algum. Sem webcam, o mouse funciona como alternativa.

## Experimentos

| Área | Experimento | Disponível em |
|---|---|---|
| Física | Pêndulo Simples | Página · Museu Virtual |
| Física | Lançamento de Projétil | Página |
| Física | Sistema Solar | Página |
| Física | Ondas Mecânicas | Página |
| Física | Você é o Móvel | Webcam |
| Química | Modelo de Bohr | Página · Museu Virtual · RA · RV |
| Química | Geometria Molecular (VSEPR) | Página · Museu Virtual · RA |
| Química | Lei de Boyle com as Mãos | Webcam |
| Biologia | Dupla Hélice de DNA | Página · Museu Virtual · RA · RV |
| Biologia | Dissecação Guiada por Gestos | Webcam |

---

## O diferencial técnico: a arquitetura

A principal contribuição do projeto, do ponto de vista da Computação, é a **arquitetura de software** que organiza os experimentos. O site é a prova de conceito dela.

### Experimento em três camadas

Cada experimento é separado em três camadas, cada uma com uma responsabilidade:

| Camada | Responsabilidade | Depende de |
|---|---|---|
| **Modelo científico** (`physics.ts`) | Equações, integradores numéricos, tabelas de dados | Nada: TypeScript puro |
| **Apresentação** (`scene.ts`) | Desenha o fenômeno em 3D (Three.js) ou 2D (canvas) | Modelo |
| **Página** (`index.tsx`) | Interface React e controles | Apresentação |

As dependências só apontam para dentro. O modelo científico não sabe que existe navegador, React ou Three.js, por isso pode ser verificado isoladamente.

### Contrato "montável" e múltiplos hospedeiros

O experimento **não cria sua própria janela 3D**. Ele segue um contrato mínimo:

```ts
mount({ root }, config) → { update(config), tick(dt), dispose() }
```

Ou seja, ele sabe montar seus objetos num grupo, avançar no tempo, reagir a parâmetros e se liberar da memória. O renderizador, a câmera, as luzes e o laço de animação ficam com quem o **hospeda**:

```
                    ┌─► página do experimento   (Galeria)
experimento ────────┼─► sala interativa         (Museu Virtual)
                    └─► realidade aumentada     (WebXR + hit-test)
```

Com isso, **o mesmo Modelo de Bohr** aparece na página, no museu e em RA sem duplicar uma linha de código de cena.

### Controles declarativos

Os parâmetros de cada experimento são descritos como **dados** (nome, tipo, intervalo, valor inicial), e não como componentes de tela. A partir dessa descrição, o mesmo painel é montado automaticamente na página, no HUD do Museu Virtual e no painel ⚙ da realidade aumentada.

### Abstração de entrada

Os experimentos de webcam não conhecem o MediaPipe. Eles recebem a entrada por uma função, como `readPosition()` ou `readWalls()`, que pode ser alimentada pela mão rastreada ou pelo mouse. Trocar ou desligar a câmera não afeta a simulação.

### Evidências medidas

Números registrados durante o desenvolvimento:

- Novas formas de apresentação (museu, realidade aumentada) foram adicionadas **sem nenhuma alteração nos modelos científicos**.
- Cada sala do Museu Virtual é descrita por um arquivo de **29 a 71 linhas**.
- Cada experimento em realidade aumentada é descrito por **cerca de 20 linhas**.
- Duas cenas de RA duplicadas foram substituídas por **um hospedeiro genérico**. Com isso, a Geometria Molecular ganhou RA sem nenhum código de cena novo.
- Na Lei de Boyle, a pressão medida pelas colisões das partículas ficou **no máximo 5,2% distante do valor teórico** (PV = constante). A lei **emerge** da simulação, em vez de ser uma fórmula programada.

---

## Destaques de implementação

- **Física numérica:**
  - integração por Euler semi-implícito, com passo máximo garantido dentro da própria simulação (independe da taxa de quadros);
  - gás ideal 2D com termostato de Berendsen;
  - velocidade estimada por regressão linear sobre a trajetória da mão, para reduzir o ruído do rastreamento.
- **Gestos robustos:**
  - pinça com **histerese**, para o objeto não ficar "piscando" entre pegar e soltar;
  - distâncias normalizadas pelo tamanho da palma, para funcionar a qualquer distância da câmera;
  - suavização do sinal e espelhamento coerente com o vídeo.
- **WebXR na prática:**
  - *hit-test* para detectar superfícies reais;
  - *dom-overlay* para ter interface HTML sobre a câmera;
  - tratamento de `beforexrselect`, para um toque no painel não reposicionar o objeto;
  - laço com `setAnimationLoop`.
- **Gestão de memória da GPU:** todo recurso 3D (geometria, material, textura, renderizador, observadores) é liberado explicitamente ao sair. Isso é essencial numa SPA em que o usuário entra e sai de dezenas de cenas.
- **Navegação sem servidor:** rotas por *hash* + History API, com botão voltar do navegador funcionando e link direto para cada experimento, compatível com hospedagem estática.
- **Descoberta automática:** as salas do museu e os textos de teoria são encontrados pelo `import.meta.glob` do Vite. Basta criar o arquivo na pasta do experimento.
- **Responsivo e com tema:** modo claro e escuro; painel lateral no desktop e *bottom sheet* no celular; controles de toque no museu.
- **Deploy contínuo:** cada push na `main` dispara o build pelo GitHub Actions e a publicação no GitHub Pages.

## Tecnologias

| Tecnologia | Uso |
|---|---|
| **React 19 + TypeScript** | Interface e composição das páginas |
| **Vite** | Desenvolvimento (com HTTPS local para câmera e WebXR) e build |
| **Three.js** | Renderização 3D sobre WebGL |
| **WebXR Device API** | Realidade virtual (`immersive-vr`) e aumentada (`immersive-ar`, hit-test, dom-overlay) |
| **MediaPipe Tasks Vision** | Rastreamento de 21 pontos de cada mão, no dispositivo |
| **Canvas 2D** | Simulações e gráficos dos experimentos de webcam |
| **marked** | Renderização dos textos de Teoria e Como foi feito (Markdown) |
| **GitHub Actions + GitHub Pages** | Integração e entrega contínuas, hospedagem estática gratuita |

## O que eu fiz

Projeto individual, da concepção à publicação:

- levantamento do problema e análise de soluções existentes (PhET, ChemCollective, Labster, Merge EDU);
- definição dos requisitos funcionais e não funcionais;
- projeto e implementação da arquitetura e de todos os experimentos;
- Museu Virtual, hospedeiro de realidade aumentada e integração com a webcam;
- textos teóricos para o estudante e documentação técnica de cada experimento;
- pipeline de deploy;
- redação da monografia.

## Limitações e próximos passos

- **Limitações:**
  - a realidade aumentada pela web depende de Android com Chrome e ARCore (o Safari do iPhone não implementa WebXR AR);
  - a realidade virtual depende de um headset;
  - o modelo de rastreamento das mãos é baixado na primeira utilização.
- **Próximos passos:**
  - experimentos de novas áreas (computação gráfica, engenharia);
  - estudo de impacto pedagógico com turmas do ensino médio;
  - Museu Virtual em RV e colaborativo;
  - rastreamento do corpo inteiro;
  - uma ferramenta para que professores criem experimentos sem programar.

---

**Palavras-chave:** ensino de Ciências · laboratório virtual · computação gráfica · realidade aumentada · realidade virtual · WebXR · visão computacional · arquitetura de software · Three.js · React · TypeScript
