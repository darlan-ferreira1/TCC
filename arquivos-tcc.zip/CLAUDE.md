# CLAUDE.md

Guia para o Claude Code neste repositório. **Arquivo não versionado** (listado em `.git/info/exclude`, assim como `ARQUITETURA.md`).

## Contexto

CLARA.js — TCC de Ciência da Computação. SPA com experimentos 3D de Física, Química e Biologia (Three.js), com variantes VR/AR (WebXR) e interação por gestos (MediaPipe). Agora estamos no **TCC2**: a tese é que a **arquitetura de software** do site é a contribuição e o site é a prova de conceito. Antes de mudanças estruturais, leia `ARQUITETURA.md` (raiz). Cada pasta de experimento tem um `README.md` explicando como ele foi feito.

O autor fez o projeto com muita ajuda de IA e não conhece todo o código: explique as mudanças em português, de forma didática.

## Regras do usuário

- **Nunca** faça `git commit`, `git push` nem crie PR. O usuário versiona sozinho.
- Anotações pessoais não vão para o Git: `CLAUDE.md`, `ARQUITETURA.md`, `run.txt`, os `.txt` da raiz, `desc-portfolio.md`, `docs/`, `tccfiles/` e os PDFs do TCC. Desde 05/11/2026, eles estão no `.gitignore` da raiz, a pedido do usuário.
- Escreva documentação, comentários e textos de UI em português (pt-BR).

## Comandos (rodar dentro de `frontend/`)

```bash
npm install
npm run dev      # https://localhost:5173/CLARA.js/ (HTTPS autoassinado, necessário para câmera/WebXR)
npm run build    # tsc -b && vite build → dist/  (é o que o CI roda; erro de TS quebra o deploy)
npm run lint
npm run preview
```

Testes de ponta a ponta em `frontend/tests/e2e` (`npm run test:e2e`; ver `frontend/tests/README.md`). Depois de mudar código, rode no mínimo `npm run build` e `npm run lint`.

Deploy: push na `main` → `.github/workflows/deploy.yml` → GitHub Pages (`https://darlan-ferreira1.github.io/CLARA.js/`). `vite.config.ts` tem `base: '/CLARA.js/'` — não remover.

## App nativo (Tauri 2 — `frontend/src-tauri/`)

Instaladores para Windows/Linux (o Android é TWA, ver abaixo). O Rust é só a "casca": abre o WebView do sistema e carrega o mesmo `dist/` do site; nenhuma lógica de experimento em Rust. `vite.config.ts` detecta `TAURI_ENV_PLATFORM` → `base: '/'` e sem `basicSsl` (o site normal continua com `/CLARA.js/` e HTTPS). Comandos em `frontend/`: `npm run tauri dev`, `npm run tauri build` (Windows: `.msi` + `-setup.exe` em `src-tauri/target/release/bundle/`). Toolchain instalado via winget: rustup (`~/.cargo/bin`, pode precisar abrir novo terminal) + VS 2022 Build Tools (C++). Linux só compila em Linux → workflow `.github/workflows/instaladores.yml` (manual ou tag `v*`, gera Release em rascunho). Ícone provisório: `src-tauri/app-icon.svg` → `npx tauri icon src-tauri/app-icon.svg`. `lib.rs` libera a câmera (`on_permission_request`) e, no Linux, liga `enable-media-stream` do WebKitGTK (só compila em Linux — validar pelo workflow). Instaladores em pt-BR. WebXR (RA/RV) não existe no WebView: `core/platform.ts` (`isNativeApp`) + campo `xr` do `registry.ts` → Galeria do app mostra RA/RV como "SÓ NO SITE".

## Offline (PWA) e Android (TWA)

- `scripts/mediapipe-assets.mjs` (hooks `predev`/`prebuild`) copia o WASM do MediaPipe de `node_modules` e baixa o modelo uma vez para `public/mediapipe/` (gerado, no `.gitignore`). `core/handTracking.ts` usa `BASE_URL + 'mediapipe/…'` — nada de CDN.
- Fontes via `@fontsource/*` em `main.tsx` (sem Google Fonts).
- `vite-plugin-pwa` no `vite.config.ts` (precache de tudo, ~31 MB; `disable: tauri`); registro em `core/offline.ts` (só produção). Ícones em `public/icons/`.
- `android/`: TWA gerada pelo Bubblewrap (`twa-manifest.json` é a fonte; o resto é gerado). JDK 17 + SDK próprios em `%USERPROFILE%\.bubblewrap`. Chave de assinatura FORA do repo em `D:\26\chaves-clarajs\` (senha no LEIA-ME-SENHA.txt). No terminal do Claude Code, `bubblewrap build` só funciona após `Remove-Item Env:NoDefaultCurrentDirectoryInExePath` (PowerShell). Ver `android/README.md`.
- Documentação completa (para a monografia) e roteiro de testes T-01…T-36: `docs/DISTRIBUICAO.md`.

## Monografia (pasta `tccfiles/`)

O texto oficial fica no Overleaf, e o usuário cola nele o que está em `tccfiles/`, com um `.txt` por capítulo do `tcc2.pdf`. **Não compilar LaTeX.** O texto é do usuário: não corrigir o conteúdo sem ele pedir. Valores não medidos ficam como `\pendente`.

- `DarlanObs:{...}` nesses arquivos é uma observação do usuário: leia, altere o texto ou argumente, e apague a marca.
- Foco só no ensino médio. A banca pediu para apresentar o TCC como prova de conceito, sem o tom de salvar a educação, já que PhET, Labster e ChemCollective existem.
- Trabalhos Futuros são ideias que podem virar novos trabalhos. Os testes ficam nos Resultados (`sec:res-testes-versoes`); a Conclusão só os resume.
- A banca gosta de tabelas pequenas, figuras e fórmulas.
- Para retomar o trabalho, leia na raiz (arquivos não versionados): `depois.txt` (checklist do usuário e artigos para ler), `analisesoftwares.txt` (notas dos testes dos softwares relacionados) e `possocopiar.txt` (experimentos que ele pode recriar).
- Responda de forma curta: listas longas vão para o `depois.txt`.

## Arquitetura em uma página

- `src/App.tsx`: roteamento por hash (`#/simple-pendulum`) com `history.pushState` + `popstate`, sem react-router; tema (`dark`/`light`, classe `.light` no `<html>`); sem store global. Navegue sempre com `navigate(p)` e volte com `goBack(fallback)` — nunca `setPage` direto, senão o botão voltar do navegador dessincroniza.
- `src/simulations/registry.ts`: metadados dos experimentos (galeria da `Home` é gerada daqui). `folder`/`theoryFolder` dizem onde estão o `README.md` e o `teoria.md`.
- `src/components/ExperimentShell/`: moldura que o `App.tsx` coloca em volta de **todo** experimento (tabela `EXPERIMENTS`). Fornece os botões Teoria / Como foi feito / Voltar (posição fixa no canto superior direito) e o painel de Markdown (lateral no desktop, *bottom sheet* em telas ≤ 640 px). Os experimentos **não** têm mais botão Voltar nem prop `onBack`.
- `src/core/`: contrato **montável** (`mountable.ts`: `mount({root}, cfg) → { update, tick(dt), dispose }`), hospedeiro de página (`hostInPage.ts`: renderer/câmera/OrbitControls/luzes/laço) e controles declarativos (`controls.ts`: `ControlDef`). Já migrados: Pêndulo, Geometria Molecular, DNA e Bohr — o `scene.ts` deles exporta o objeto montável **e** mantém `create*Scene` com a assinatura antiga (via `hostInPage`), então `index.tsx` não muda. Os demais experimentos ainda estão no contrato antigo (os dois convivem — ver seção 22 do `ARQUITETURA.md`).
- **Sala interativa**: um `sala.ts` na pasta do experimento (exporta `sala: InteractiveRoom`, ver `museum/interactiveRoom.ts`) dá a ele uma sala no Museu Virtual. É descoberto sozinho por `import.meta.glob`. Regras: luz que faz parte do fenômeno fica no `mount`, luz de ambiente é do hospedeiro; garantias de precisão (ex.: passo máximo do integrador) ficam no `tick`, não no laço.
- `src/simulations/<area>/<Nome>/`, convenção de 3 arquivos:
  - `physics.ts` — domínio puro (equações, integradores, tabelas). **Não importa three nem react.**
  - `scene.ts` — Three.js imperativo. Exporta `createXScene(canvasOuContainer, config, bg?) → { update(cfg), dispose() }`. **Não importa react.**
  - `index.tsx` — componente React: cria a cena no `useEffect`, guarda em `useRef`, chama `scene.update()` direto nos handlers dos controles, chama `dispose()` no cleanup.
- Variantes `xr*` (VR): a cena cria o próprio canvas dentro de um `<div>`, usa `renderer.xr.enabled = true`, `VRButton` e **`renderer.setAnimationLoop`** (obrigatório em WebXR, `requestAnimationFrame` não funciona dentro da sessão). Ainda no contrato antigo.
- Variantes `ar*` (AR): **não têm mais cena própria**. São um `ar.ts` (`ARDefinition`: experimento montável + `controls`/`toConfig` reaproveitados do `sala.ts` + `scale`/`lift`/`previewDistance`) exibido pelo hospedeiro genérico `src/ar/` (`hostInAR`: hit-test + retícula, tocar para posicionar, arrastar/pinça/girar, dom-overlay com ⚙ Ajustes). No `App.tsx`: `<ARExperiment def={...} title=... />`. Dar AR a um experimento montável = novo `ar.ts` + entrada no registro + linha no `App.tsx`. Ver seção 23 do `ARQUITETURA.md`.
- `src/components/ControlsHud/`: painel genérico de `ControlDef`, compartilhado pelo Museu Virtual (Tab/⚙) e pelo AR (⚙).
- `src/pages/About.tsx`: página Sobre (sigla **CLARA = Centro de Laboratórios para Aprendizagem e Representação Analítica**). Instituição e orientador ficam em `PROJECT`, no topo do arquivo (vazio = não aparece).
- `src/museum/`: Museu Virtual — museu 3D em 1ª pessoa (WASD + `PointerLockControls`), mesma convenção de 3 camadas (`layout.ts` puro / `scene.ts` / `index.tsx`). Fases em `levels.ts` (salão e salas, mesma interface `Level`), construção 3D compartilhada em `builders.ts`; o HUD de ajustes é o `components/ControlsHud` (compartilhado com o AR). Troca de fase = véu preto na câmera + troca de grupo na MESMA cena/renderer. As portas são geradas do `registry.ts`, mas só para experimentos que têm `sala.ts` (os demais ficam só na galeria). Etapas 1 (desktop, WASD) e 2 (celular: `TouchControls.tsx`, joystick + arrastar para olhar) prontas; planejado: refatorar cenas XR para "montar num grupo" e compartilhar a sessão WebXR (3), museu em VR com teletransporte (4), AR em maquete/portais (5).
- **Webcam / MediaPipe**: rastreamento de mão comum em `core/handTracking.ts` (landmarks crus, `mirrorX`, `palmSpanPx`, `coverMapping` para alinhar desenho e vídeo com `object-fit: cover`) + gancho React `components/handInput/useHandCamera.ts` (abre câmera e modelo; `readHands()` só infere em quadro novo; expõe `cameraError`/`trackerError` para cair no mouse). Usado por `physics/HandKinematics` ("Você é o Móvel") e `chemistry/BoyleHands` ("Lei de Boyle com as Mãos"), cujas "cenas" são canvas 2D (não Three.js) e recebem a entrada por função (`readPosition`/`readWalls`), nunca o MediaPipe direto.
- **Controle de videogame**: `core/gamepad.ts` (Gamepad API → quadro com analógicos e botões; mapeamento em `GamepadLayout`). No Museu, soma ao vetor de movimento e ao `rotateLook` do toque; o React escolhe o modo com `setGamepadMode` (off/play/hud) e recebe `onGamepadAction` (resume/menu/pause) e `onGamepadHud` (D-pad no HUD, que ajusta os parâmetros com `stepControl`, de `core/controls.ts`). Nas variantes `xr*`, `core/gamepadRig.ts` põe a câmera (e os controladores XR) num rig que o controle move só durante a sessão WebXR.
- `biology/FrogDissection`: `gestures.ts` (sobre `core/handTracking.ts` → `PinchState` em NDC, com histerese) + `scene.ts` (máquina de estados + raycasting). O mouse é fallback e produz o mesmo `PinchState`.

### Adicionar um experimento

1. Criar `src/simulations/<area>/<Nome>/` com `physics.ts`, `scene.ts`, `index.tsx`, `README.md` (técnico) e `teoria.md` (para o aluno) — seguir o modelo dos existentes. Não colocar botão Voltar no `index.tsx` (a moldura já tem) e deixar o canto superior direito livre.
2. Adicionar entrada em `registry.ts` com `folder` (e `theoryFolder` se reaproveitar a teoria de outra pasta, como as variantes VR/AR).
3. Importar em `App.tsx`, adicionar o id ao array `PAGES` e à tabela `EXPERIMENTS`.

## Convenções e armadilhas

- Estilo: `style={{}}` inline com `var(--token)` de `index.css`; as cenas recebem a cor de fundo em hex (objeto `c` em cada `index.tsx`). Tailwind está instalado, mas quase não é usado.
- Todo recurso do Three.js criado precisa ser liberado em `dispose()` (geometrias, materiais, texturas, renderer, `ResizeObserver`, loop). React StrictMode monta/desmonta efeitos duas vezes em dev — um `dispose` incompleto aparece como canvas ou loop duplicado.
- Use `dt = Math.min((t - last) / 1000, 0.05)` no loop (evita saltos ao voltar de aba em segundo plano).
- Limite `setPixelRatio(Math.min(window.devicePixelRatio, 2))`.
- Dados de alta frequência não devem passar por `setState` (ver `onTimeUpdate` + `ref.textContent` no Sistema Solar).
- A pasta `chemistry/xrBhorModel` tem erro de grafia ("Bhor"); o import em `App.tsx` depende desse nome.
- `components/ui/ExperimentCard.tsx` e `ExperimentDetails.tsx` são código morto.
- MediaPipe: WASM e modelo são servidos de `public/mediapipe/` (copiados/baixados pelo `scripts/mediapipe-assets.mjs`); a versão do WASM acompanha automaticamente o pacote `@mediapipe/tasks-vision` (fixado em `1.0.1`).
- A lista completa de débitos conhecidos (D1–D22) está na seção 16 de `ARQUITETURA.md`. Ao corrigir um, atualize essa tabela e o `README.md` do experimento.
- A seção 22 de `ARQUITETURA.md` é a **proposta** de evolução do contrato de cena (`MountableExperiment` + hospedeiros `hostInPage`/`hostInRoom`, migração incremental começando pelo Pêndulo). Antes de mexer em `scene.ts` para o museu, siga essa proposta e atualize a tabela de status dela.
- A seção 21 de `ARQUITETURA.md` é um **diário vivo de argumentos para a monografia**. Sempre que uma mudança gerar evidência concreta sobre a arquitetura (linhas removidas, arquivos não tocados, reuso, desempenho…), acrescente uma entrada `A<n>` seguindo o modelo da seção, com números medidos (não estimados).
- Os `README.md` dos experimentos são exibidos publicamente no site (aba "Como foi feito"); não escreva neles nada que não deva ser público.
