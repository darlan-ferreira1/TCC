# CLARA.js — Arquitetura de Software

> Documento técnico de referência para o TCC2. **Não versionado** (excluído via `.git/info/exclude`).
> Descreve a arquitetura do código como ele está no commit `cee8aa7` (21/09/2026), aponta onde cada decisão aparece no código, sugere figuras/diagramas para a monografia e enquadra o projeto como contribuição para a Ciência da Computação.

---

## Sumário

1. [Visão geral](#1-visão-geral)
2. [A pergunta de pesquisa e a contribuição para a Computação](#2-a-pergunta-de-pesquisa-e-a-contribuição-para-a-computação)
3. [Pilha tecnológica e justificativas](#3-pilha-tecnológica-e-justificativas)
4. [Visão de implantação (deploy)](#4-visão-de-implantação-deploy)
5. [Estrutura do código-fonte](#5-estrutura-do-código-fonte)
6. [Arquitetura em camadas](#6-arquitetura-em-camadas)
7. [O contrato de cena: `create*Scene → { update, dispose }`](#7-o-contrato-de-cena-createscene--update-dispose)
8. [Ciclo de vida: React ↔ Three.js](#8-ciclo-de-vida-react--threejs)
9. [O laço de simulação (game loop)](#9-o-laço-de-simulação-game-loop)
10. [Multimodalidade: Desktop, VR, AR e Gestos](#10-multimodalidade-desktop-vr-ar-e-gestos)
11. [Pipeline de visão computacional (MediaPipe)](#11-pipeline-de-visão-computacional-mediapipe)
12. [Navegação, registro de experimentos e tema](#12-navegação-registro-de-experimentos-e-tema)
13. [Gerenciamento de recursos de GPU](#13-gerenciamento-de-recursos-de-gpu)
14. [Catálogo de experimentos](#14-catálogo-de-experimentos)
15. [Atributos de qualidade (ISO/IEC 25010)](#15-atributos-de-qualidade-isoiec-25010)
16. [Débitos técnicos e problemas encontrados](#16-débitos-técnicos-e-problemas-encontrados)
17. [Sugestões de figuras e diagramas para o TCC2](#17-sugestões-de-figuras-e-diagramas-para-o-tcc2)
18. [Roteiro sugerido de evolução para o TCC2](#18-roteiro-sugerido-de-evolução-para-o-tcc2)
19. [Métricas do código (baseline)](#19-métricas-do-código-baseline)
20. [Referências sugeridas](#20-referências-sugeridas)
21. [Diário de argumentos concretos (registro vivo)](#21-diário-de-argumentos-concretos-registro-vivo)
22. [Evolução do contrato de cena: de "dona de tudo" a "montável"](#22-evolução-do-contrato-de-cena-de-dona-de-tudo-a-montável)
23. [Realidade aumentada: o terceiro hospedeiro (`hostInAR`)](#23-realidade-aumentada-o-terceiro-hospedeiro-hostinar)

---

## 1. Visão geral

**CLARA.js** é uma *Single Page Application* (SPA) que funciona como um **laboratório virtual de ciências** executado inteiramente no navegador. Ela reúne 12 experimentos interativos 3D de Física, Química e Biologia, oferecidos em até quatro **modalidades de interação**:

| Modalidade | Tecnologia | Dispositivo | Experimentos |
|---|---|---|---|
| Desktop/mobile 3D | WebGL via Three.js + OrbitControls | Qualquer navegador | Pêndulo, Projétil, Sistema Solar, Ondas, Bohr, Geometria Molecular, DNA |
| Realidade Virtual (VR) | WebXR `immersive-vr` (`VRButton`) | Headset (Quest etc.) | Bohr XR, DNA XR |
| Realidade Aumentada (AR) | WebXR `immersive-ar` (`ARButton`) | Celular Android/ARCore | Bohr AR, DNA AR |
| Interação por gestos | MediaPipe Hand Landmarker + webcam | Qualquer PC com câmera | Dissecação do sapo |

Características arquiteturais centrais:

- **100% client-side**: não há backend. Todo cálculo (física, renderização, inferência de rede neural) roda no dispositivo do usuário.
- **Zero instalação**: basta uma URL (`https://darlan-ferreira1.github.io/CLARA.js/`). Não há loja de apps, plugin nem build nativo.
- **Hospedagem estática**: o artefato de build é um conjunto de arquivos estáticos publicado no GitHub Pages por CI/CD.
- **Experimentos isolados**: cada experimento é um módulo autocontido em sua pasta, ligado ao resto da aplicação por dois pontos de registro.
- **Separação domínio × renderização × UI**: o modelo científico (`physics.ts`) não conhece Three.js; a cena (`scene.ts`) não conhece React; o componente (`index.tsx`) não conhece WebGL.

---

## 2. A pergunta de pesquisa e a contribuição para a Computação

### 2.1 Pergunta

> *Como este site contribui para a pesquisa em Ciência da Computação?*

### 2.2 Resposta proposta

A contribuição **não** é cada simulação em si (o conteúdo de Física/Química/Biologia é conhecido e as equações são de livro-texto). A contribuição é a **arquitetura de software** que permite construir, de forma padronizada, laboratórios virtuais **multimodais** (tela, VR, AR e gestos) usando **apenas padrões abertos da Web**, e o site é a **prova de conceito** (PoC) que demonstra que essa arquitetura é viável.

Formulação sugerida para a monografia:

> *Este trabalho propõe uma arquitetura de software em camadas para laboratórios virtuais de ciências executados no navegador, que integra renderização 3D (WebGL/Three.js), realidade estendida (WebXR) e interação natural por visão computacional (MediaPipe) sob um mesmo contrato de módulo. A arquitetura é validada por uma prova de conceito com 12 experimentos em três áreas do conhecimento e quatro modalidades de interação.*

### 2.3 Elementos que sustentam a contribuição (e onde estão no código)

| # | Elemento arquitetural | Por que é relevante para a Computação | Evidência no código |
|---|---|---|---|
| C1 | **Separação em três camadas por experimento** (modelo científico / adaptador de renderização / componente de UI) | Aplica *separation of concerns* e o padrão *functional core, imperative shell* a um domínio (simulação científica interativa) onde normalmente tudo fica acoplado em um único script | `physics.ts` (funções puras), `scene.ts` (imperativo, Three.js), `index.tsx` (declarativo, React) em todas as pastas de `src/simulations/` |
| C2 | **Contrato uniforme de módulo de cena** (`create*Scene(alvo, config) → { update, dispose }`) | Define uma interface estável entre o mundo declarativo (React) e o imperativo (WebGL). É o que permite adicionar experimentos sem mexer no núcleo | Ex.: `simulations/physics/Pendulum/scene.ts:26-29` |
| C3 | **Reuso do núcleo de domínio entre modalidades** | Um mesmo modelo físico alimenta a versão desktop, VR e AR; muda só a camada de apresentação (escala, câmera, loop) | `xrBhorModel/scene.ts:15` e `arBohrModel/scene.ts:21` importam `computeElectronPositions` de `BohrModel/physics.ts` |
| C4 | **Abstração de entrada independente de dispositivo** (`PinchState`) | A cena só consome `{ tracking, pinching, x, y }` em NDC. Pode vir da rede neural (MediaPipe) ou do mouse. É um exemplo de *adapter* / *input abstraction layer* com degradação graciosa | `FrogDissection/gestures.ts:19-24`, `FrogDissection/index.tsx:41-62` |
| C5 | **Aprimoramento progressivo** (*progressive enhancement*) | Toda cena XR funciona também em tela comum (OrbitControls); o botão VR/AR só habilita a imersão se o hardware suportar; a dissecação cai para mouse se câmera ou modelo falharem | `renderer.xr.addEventListener('sessionstart'…)` nas cenas XR/AR; `cameraError`/`trackerError` em `FrogDissection/index.tsx` |
| C6 | **Gestão explícita de recursos de GPU** | O GC do JavaScript não libera buffers da GPU. A arquitetura obriga cada cena a implementar `dispose()`, ligado ao *cleanup* do `useEffect` | Todas as `scene.ts`; ver seção 13 |
| C7 | **Registro declarativo de experimentos** | Metadados (título, categoria, disponibilidade) ficam numa única fonte de verdade; a galeria é gerada a partir dela | `simulations/registry.ts` |
| C8 | **Pipeline de entrega contínua estático** | Demonstra que a solução é distribuível a custo zero e reproduzível | `.github/workflows/deploy.yml` |

### 2.4 Como enquadrar metodologicamente

Sugestão: **Design Science Research (DSR)**. Em DSR o produto da pesquisa é um *artefato* (aqui, a arquitetura), e a pesquisa consiste em (1) identificar o problema, (2) projetar o artefato, (3) demonstrá-lo (a PoC) e (4) avaliá-lo. Isso casa exatamente com a narrativa "a arquitetura é a contribuição e o site é a prova de conceito".

Formas de **avaliar** a arquitetura no TCC2 (escolha 2 ou 3):

1. **Extensibilidade medida**: quantos arquivos/linhas são tocados para adicionar um experimento novo. Hoje: 3 arquivos novos + 2 edições (`registry.ts` e `App.tsx`). Pode-se implementar um experimento novo durante o TCC2 e registrar o esforço.
2. **Reuso entre modalidades**: % do código de domínio compartilhado entre desktop/VR/AR. Hoje o Bohr reutiliza 100% do `physics.ts`; o DNA reutiliza 0% (duplicado — ver débito D3). Corrigir e medir antes/depois é um resultado concreto.
3. **Desempenho**: FPS médio e tempo de frame por experimento em 2–3 dispositivos (PC, celular, headset). Ferramenta: `renderer.info`, `performance.now()`, Chrome DevTools.
4. **Portabilidade**: matriz navegador × dispositivo × modalidade (o que funciona onde).
5. **Usabilidade** (opcional, envolve pessoas): questionário SUS com alunos/professores. Exige cuidado ético (TCLE).
6. **Análise arquitetural qualitativa**: cenários de atributos de qualidade no estilo ATAM (ver seção 15).

---

## 3. Pilha tecnológica e justificativas

| Camada | Tecnologia | Versão (`frontend/package.json`) | Papel |
|---|---|---|---|
| Linguagem | TypeScript | ~6.0 | Tipagem estática do contrato de cena e dos modelos |
| UI | React | 19.2 | Telas, painéis de controle, estado de UI |
| 3D | Three.js | 0.184 | Grafo de cena, WebGL, câmera, luzes, `OrbitControls`, `VRButton`, `ARButton` |
| XR | WebXR Device API (via Three.js) | padrão W3C | Sessões `immersive-vr` e `immersive-ar` |
| Visão computacional | `@mediapipe/tasks-vision` | 1.0.1 (fixada) | Detecção de 21 *landmarks* da mão em tempo real (WASM + GPU) |
| Estilo | Tailwind CSS 4 + CSS custom properties | 4.3 | Tema claro/escuro (na prática quase tudo é `style={{}}` inline) |
| Build | Vite 8 + `@vitejs/plugin-react` | 8.0 | Dev server com HMR e build de produção |
| HTTPS dev | `@vitejs/plugin-basic-ssl` | 2.3 | Certificado autoassinado: câmera e WebXR exigem *secure context* |
| Lint | ESLint 10 + typescript-eslint + react-hooks | — | Qualidade estática |
| CI/CD | GitHub Actions → GitHub Pages | — | Build e publicação automáticos a cada push na `main` |

**Justificativas que valem para a monografia:**

- **Three.js** em vez de Unity/Unreal: roda nativamente no navegador sem plugin, tem suporte de primeira classe a WebXR e é a biblioteca WebGL mais adotada; Unity WebGL gera *bundles* grandes e WebXR nele depende de plugins de terceiros.
- **WebXR** em vez de SDKs nativos (ARCore/ARKit/Oculus SDK): um único código atende headset e celular, sem publicar em lojas.
- **MediaPipe Tasks** em vez de TensorFlow.js puro: entrega o modelo de mão já treinado e otimizado, com *delegate* GPU, numa API de alto nível (`HandLandmarker`).
- **React** apenas como camada de UI: a renderização 3D fica fora do ciclo de reconciliação do React (ver seção 8), evitando *re-render* a 60 Hz.
- **Sem backend**: reduz custo, superfície de ataque e complexidade; a privacidade é preservada porque o vídeo da webcam nunca sai do dispositivo.

---

## 4. Visão de implantação (deploy)

```
 Desenvolvedor ──git push──▶ GitHub (main)
                                │
                                ▼
                    GitHub Actions (ubuntu-latest, Node 20)
                    npm ci → npm run build (tsc -b && vite build)
                                │  frontend/dist/
                                ▼
                         GitHub Pages (estático)
                    https://darlan-ferreira1.github.io/CLARA.js/
                                │ HTTPS
                                ▼
 ┌──────────────────────── Navegador do usuário ─────────────────────────┐
 │  SPA React + Three.js (bundle único)                                   │
 │  WebGL (GPU) · WebXR runtime (headset/ARCore) · getUserMedia (webcam)  │
 │        │                                                               │
 │        └─ em tempo de execução, só na Dissecação, baixa de CDNs:       │
 │             • cdn.jsdelivr.net → WASM do MediaPipe Tasks Vision        │
 │             • storage.googleapis.com → hand_landmarker.task (modelo)   │
 └────────────────────────────────────────────────────────────────────────┘
```

Pontos técnicos:

- `vite.config.ts` define `base: '/CLARA.js/'` porque o site é uma *project page*. Renomear o repositório quebra os caminhos se isso não for atualizado.
- O workflow tem dois jobs (`build` → `deploy`), usa `concurrency: pages` para cancelar deploys antigos e permissões mínimas (`pages: write`, `id-token: write`).
- **Dependência externa em tempo de execução**: o MediaPipe busca WASM e modelo em CDNs (`FilesetResolver` em `gestures.ts:13-14`). Sem internet ou com CDN bloqueada, a dissecação cai para o modo mouse. Para o TCC2 vale considerar servir esses arquivos de `public/` (auto-hospedagem).
- `vite.config.ts` ainda tem `proxy: { '/api': 'http://localhost:3000' }`, resquício do backend Fastify removido no commit `b557f09`. Não afeta produção.

---

## 5. Estrutura do código-fonte

```
TCC/
├── .github/workflows/deploy.yml     # CI/CD → GitHub Pages
├── README.md                        # visão geral pública (versionado)
├── CLAUDE.md                        # guia para o Claude Code (NÃO versionado)
├── ARQUITETURA.md                   # este documento (NÃO versionado)
└── frontend/
    ├── index.html                   # ponto de montagem (<div id="root">)
    ├── vite.config.ts               # base '/CLARA.js/', plugins react/tailwind/ssl
    ├── package.json
    └── src/
        ├── main.tsx                 # createRoot + StrictMode
        ├── App.tsx                  # "roteador" por useState + tema global
        ├── index.css                # tokens de tema (dark/light) + Tailwind
        ├── pages/
        │   ├── ModeSelect.tsx       # tela inicial: Galeria × Museu Virtual
        │   ├── Home.tsx             # galeria (busca, filtro, cards)
        │   └── About.tsx            # página Sobre (sigla CLARA, projeto, tecnologias)
        ├── museum/                  # Museu Virtual: museu 1ª pessoa (layout/scene/index) — ver 21, A4
        ├── components/
        │   ├── ExperimentShell/     # moldura comum: Teoria / Como foi feito / Voltar (ver 21, A2)
        │   └── ui/                  # ExperimentCard/Details — CÓDIGO MORTO
        └── simulations/
            ├── registry.ts          # metadados de todos os experimentos
            ├── physics/   Pendulum · Projectile · SolarSystem · Waves
            ├── chemistry/ BohrModel · xrBhorModel · arBohrModel · MolecularGeometry
            └── biology/   DnaHelix · xrDnaHelix · arDnaHelix · FrogDissection
```

Cada pasta de experimento contém um `README.md` com a documentação técnica (exibida no site na aba "Como foi feito") e, nos experimentos base, um `teoria.md` com o texto para o aluno (aba "Teoria").

---

## 6. Arquitetura em camadas

### 6.1 Visão macro

```
┌──────────────────────────────────────────────────────────────────────┐
│ CAMADA DE APLICAÇÃO (React)                                          │
│ main.tsx → App.tsx (máquina de estados de página + tema)             │
│ pages/ModeSelect · pages/Home (lê registry.ts) · pages/About         │
└───────────────────────────────┬──────────────────────────────────────┘
                                │ props: onBack, theme
┌───────────────────────────────▼──────────────────────────────────────┐
│ CAMADA DE APRESENTAÇÃO DO EXPERIMENTO — index.tsx (React)            │
│ canvas/container · sliders/selects · overlays HTML · estado de UI    │
└───────────────┬───────────────────────────────▲──────────────────────┘
                │ create*Scene(), update(cfg),  │ callbacks (onTimeUpdate,
                │ dispose()                     │ onExtract, onElementChange…)
┌───────────────▼───────────────────────────────┴──────────────────────┐
│ CAMADA DE RENDERIZAÇÃO — scene.ts (Three.js, imperativo)             │
│ renderer · scene · camera · luzes · meshes · loop · XR · raycast     │
└───────────────┬──────────────────────────────────────────────────────┘
                │ chamadas a funções puras
┌───────────────▼──────────────────────────────────────────────────────┐
│ CAMADA DE DOMÍNIO — physics.ts (TypeScript puro, sem dependências)   │
│ equações, integradores numéricos, geometria, tabelas de dados        │
└──────────────────────────────────────────────────────────────────────┘
        ▲ (somente Dissecação)
┌───────┴──────────────────────────────────────────────────────────────┐
│ CAMADA DE ENTRADA — gestures.ts (MediaPipe) · fallback de mouse      │
│ produz PinchState { tracking, pinching, x, y } em NDC                │
└──────────────────────────────────────────────────────────────────────┘
```

### 6.2 Regras de dependência (direção das setas)

- `physics.ts` **não importa nada** (nem Three.js, nem React). É a camada mais estável e a mais fácil de testar.
- `scene.ts` importa `three` e o `physics.ts` do próprio experimento (ou de outro, no caso das variantes XR/AR do Bohr). **Não importa React.**
- `index.tsx` importa `react` e o `scene.ts`. Pode importar `physics.ts` para **exibir** grandezas derivadas (ex.: `period()` no Pêndulo, `waveInfo()` nas Ondas, `projectileInfo()` no Projétil) — mas não para simular.
- `App.tsx` importa todos os `index.tsx` (acoplamento central — ver débito D6).

Essa regra é a materialização de *Dependency Rule* da *Clean Architecture*: as dependências apontam para o domínio.

### 6.3 Por que separar `physics.ts` de `scene.ts`?

1. **Testabilidade**: `stepPendulum(state, config, dt)` é uma função pura; dá para testar conservação de energia sem abrir um navegador.
2. **Reuso entre modalidades**: o mesmo `computeElectronPositions` serve à tela, ao VR e ao AR (seção 10).
3. **Troca de motor gráfico**: em tese, `physics.ts` serviria a Babylon.js ou a um *canvas* 2D sem mudanças.
4. **Legibilidade científica**: o arquivo de física lê como um livro-texto (comentários com as equações).

Há dois "sabores" de `physics.ts` no projeto:

| Tipo | Descrição | Experimentos |
|---|---|---|
| **Integração numérica com estado** | `step(state, config, dt) → state` | Pêndulo (Euler semi-implícito) |
| **Solução analítica/paramétrica** | `f(t, params) → posição` | Projétil, Ondas, Sistema Solar, Bohr |
| **Geometria estática / tabelas** | gera posições ou dados sem tempo | DNA, Geometria Molecular |

---

## 7. O contrato de cena: `create*Scene → { update, dispose }`

Todas as cenas seguem a mesma forma (padrão *Factory* que devolve um *handle* com métodos — um "objeto por *closure*", sem classes):

```ts
// Forma geral (modo desktop)
export interface XScene {
  update(config: XSceneConfig): void;   // aplica novos parâmetros vindos da UI
  dispose(): void;                      // libera GPU, observers, listeners, loop
}
export function createXScene(
  canvas: HTMLCanvasElement,            // canvas criado pelo React
  config: XSceneConfig,                 // parâmetros iniciais
  bgColor?: number,                     // cor de fundo resolvida (tema)
): XScene
```

Variações do contrato encontradas no código:

| Variação | Diferença | Onde |
|---|---|---|
| Ação extra | `launch()` (máquina de estados idle/flying/landed) | `Projectile/scene.ts:26-30` |
| Consulta | `getTime()` | `SolarSystem/scene.ts:26-30` |
| Callback de saída | `onTimeUpdate(t)` passado na criação | `SolarSystem/scene.ts:47` |
| Container em vez de canvas | a cena cria o próprio `<canvas>` (necessário para XR) | todas as cenas XR/AR e Dissecação |
| Botão XR exposto | `vrButton` / `arButton` para o React posicionar | `xrBhorModel/scene.ts:44-49` |
| Eventos de volta para o React | `onElementChange`, `onBasePairsChange`, `onExtract`, `onOpenChange` (propriedades atribuíveis) | XR/AR e Dissecação |
| Entrada por frame | `updatePinch(PinchState)` | `FrogDissection/scene.ts:46-52` |

**Por que esse contrato é bom (argumento para a monografia):**

- Ele é a **fronteira** entre dois paradigmas incompatíveis: React é declarativo e re-renderiza por diferença de estado; WebGL é imperativo e precisa de um laço de 60–90 Hz. O contrato isola a mutação de estado gráfico dentro da *closure*.
- `update()` é **idempotente em relação à UI**: o React só manda "o novo estado desejado"; a cena decide se reconstrói geometria (ex.: Pêndulo reconstrói a haste quando L muda) ou só troca parâmetro (Ondas).
- `dispose()` torna o ciclo de vida **explícito e verificável**.

---

## 8. Ciclo de vida: React ↔ Three.js

### 8.1 Padrão usado em todos os `index.tsx`

```tsx
const canvasRef = useRef<HTMLCanvasElement>(null);
const sceneRef  = useRef<XScene | null>(null);       // handle imperativo
const [param, setParam] = useState(DEFAULT);         // estado de UI

useEffect(() => {
  sceneRef.current = createXScene(canvasRef.current!, DEFAULTS, bg);
  return () => { sceneRef.current?.dispose(); sceneRef.current = null; };
}, [theme]);                                          // recria ao trocar tema

function onSlider(v) { setParam(v); sceneRef.current?.update({ ...v }); }
```

Pontos-chave:

1. **`useRef` para o handle**: guardar a cena em `useState` causaria re-render; em `useRef` ela é invisível para a reconciliação.
2. **Atualização dupla no slider**: `setParam` (para o rótulo HTML) e `scene.update` (para o 3D) são chamados juntos — o React não "empurra" estado para a cena via efeito; é um *push* direto.
3. **`[theme]` como dependência**: a troca de tema destrói e recria a cena (porque `scene.background` foi fixado na criação). Efeito colateral: a cena volta aos `DEFAULTS` enquanto os sliders mantêm o último valor (débito D1).
4. **React StrictMode** (`main.tsx`): em desenvolvimento, o React monta → desmonta → monta cada efeito. Por isso `dispose()` precisa ser correto; caso contrário apareceriam dois loops ou dois canvases.
5. **Dados de alta frequência fora do React**: no Sistema Solar o tempo simulado é escrito direto no DOM via `timeDisplayRef.current.textContent`, a cada 10 frames — evita 60 re-renders/s (`SolarSystem/index.tsx:39-43`, `scene.ts:172-175`).

### 8.2 Diagrama de sequência (texto para virar figura)

```
Usuário      App.tsx        index.tsx           scene.ts              GPU
  │ clica card  │               │                   │                   │
  │────────────▶│ setPage(id)   │                   │                   │
  │             │──render──────▶│ mount <canvas>    │                   │
  │             │               │ useEffect:        │                   │
  │             │               │──createXScene()──▶│ new WebGLRenderer │
  │             │               │                   │──alloc buffers───▶│
  │             │               │                   │ requestAnimationFrame
  │             │               │◀──{update,dispose}│                   │
  │             │               │                   │◀─┐ loop 60 Hz:    │
  │             │               │                   │  │ physics(dt)    │
  │             │               │                   │──┘ render()──────▶│
  │ move slider │               │                   │                   │
  │────────────────────────────▶│ setState + update(cfg)                │
  │             │               │──────────────────▶│ rebuild/param     │
  │ "Voltar"    │               │                   │                   │
  │────────────────────────────▶│ onBack()          │                   │
  │             │◀──────────────│                   │                   │
  │             │ setPage('home')  unmount → cleanup│                   │
  │             │               │──dispose()───────▶│ cancelAnimationFrame
  │             │               │                   │──free buffers────▶│
```

---

## 9. O laço de simulação (game loop)

### 9.1 Duas formas de loop

| Forma | API | Onde | Por quê |
|---|---|---|---|
| `requestAnimationFrame` | `raf = requestAnimationFrame(animate)` | cenas desktop | Padrão do navegador, sincronizado com o *refresh* da tela |
| `renderer.setAnimationLoop(cb)` | Three.js → `XRSession.requestAnimationFrame` | cenas XR/AR e Dissecação | **Obrigatório em WebXR**: durante a sessão imersiva, o `window.requestAnimationFrame` não dispara na taxa do headset (72/90/120 Hz); só o loop da sessão XR dispara |

### 9.2 Passo de tempo

Quase todas as cenas usam **passo variável com teto** (*clamped variable timestep*):

```ts
const dt = Math.min((t - last) / 1000, 0.05);  // Pêndulo usa 0.02
```

- O teto evita o "salto" quando a aba fica em segundo plano (o navegador pausa o rAF e o próximo `dt` seria de vários segundos, desestabilizando o integrador).
- Bohr usa `THREE.Clock.getDelta()` **sem teto** (diferença menor porque a solução é analítica, mas ainda sofre salto de fase).
- **Limitação científica**: passo variável torna a simulação dependente da taxa de quadros. Para o Pêndulo (único integrador numérico) um **passo fixo com acumulador** (*fixed timestep*, Glenn Fiedler, "Fix Your Timestep!") seria mais rigoroso — boa melhoria para o TCC2.

### 9.3 Integrador numérico (Pêndulo)

Euler semi-implícito (simplético):

```
ω_{n+1} = ω_n + Δt · (−g/L) · sin θ_n
θ_{n+1} = θ_n + Δt · ω_{n+1}
```

Diferente do Euler explícito, ele não injeta energia artificialmente em osciladores, então o pêndulo não "explode" com o tempo. Note que o painel mostra o período pela aproximação de pequenos ângulos (`T = 2π√(L/g)`), mas a simulação usa `sin θ` completo — para θ₀ grande o período real é maior que o exibido. Isso é um ótimo ponto didático (e uma ótima figura: período real × aproximado em função de θ₀).

---

## 10. Multimodalidade: Desktop, VR, AR e Gestos

### 10.1 Matriz de modalidades

| Aspecto | Desktop | VR (`xr*`) | AR (`ar*`) | Gestos (Dissecação) |
|---|---|---|---|---|
| Alvo de render | `<canvas>` do React | canvas criado pela cena | canvas criado pela cena (alpha) | canvas transparente sobre `<video>` |
| Loop | rAF | `setAnimationLoop` | `setAnimationLoop` | `setAnimationLoop` (render) + rAF (input) |
| Câmera | `OrbitControls` | pose da cabeça (headset) | pose do celular (6DoF) | fixa |
| Entrada | mouse/touch + sliders | gatilhos dos controles (`selectstart`) | toque na tela (vira `select`) | pinça via MediaPipe ou mouse |
| Escala | unidades arbitrárias | **metros**, objeto enorme (imersão) | **metros**, escala de mesa/sala | unidades arbitrárias |
| Fundo | cor do tema | cor escura fixa | **transparente** (passthrough) | transparente (vídeo da webcam) |
| UI | HTML | HTML + painel 3D (`CanvasTexture`) | HTML (só fora da sessão — ver D4) | HTML |
| Fallback | — | OrbitControls na tela | OrbitControls na tela | mouse |

### 10.2 Como as variantes XR/AR reaproveitam o domínio

```
                 BohrModel/physics.ts
             (shellRadius, computeElectronPositions)
              ▲               ▲                ▲
              │               │                │
  BohrModel/scene.ts   xrBhorModel/scene.ts   arBohrModel/scene.ts
  baseRadius = 2.0     BASE_RADIUS = 2.0 m    BASE_RADIUS = 0.30 m
  ω₁ = 2.0             ω₁ = 0.7              ω₁ = 0.7
  átomo na origem      átomo em (0,1.6,−4)   átomo em (0,1.2,−1.5)
```

O **modelo é o mesmo**; o que muda são **parâmetros de apresentação** (escala em metros, posição relativa ao usuário, velocidade angular). Isso evidencia que o domínio é independente da modalidade — ponto forte do argumento C3.

Contra-exemplo (débito D3): `xrDnaHelix/scene.ts` e `arDnaHelix/scene.ts` **reimplementam** a matemática da hélice (`computeHelix`) em vez de importar `DnaHelix/physics.ts`. A tabela de 20 elementos também está copiada 3× (Bohr, XR, AR). Refatorar isso é uma melhoria mensurável.

### 10.3 Detalhes de WebXR usados

- `renderer.xr.enabled = true` + `VRButton.createButton(renderer)` / `ARButton.createButton(renderer)`: o botão consulta `navigator.xr.isSessionSupported(...)` e mostra "ENTER VR/AR" ou "VR NOT SUPPORTED".
- O sistema de coordenadas da sessão usa o *reference space* padrão do Three.js (`local-floor`): y = 0 é o chão, por isso o átomo do VR fica em y = 1,6 m (altura dos olhos).
- `renderer.xr.getController(0|1)` + evento `selectstart` = gatilho do controle (VR) ou toque na tela (AR em celular). **Atenção**: índice 0/1 não garante mão direita/esquerda; o correto é ler `event.data.handedness` no evento `connected`.
- Eventos `sessionstart`/`sessionend` desligam/religam `OrbitControls` e, no AR, trocam o *clear color* para alpha 0 (fundo transparente = câmera real aparece).
- Na VR, como HTML não aparece dentro do headset, o rótulo do elemento é desenhado num `<canvas>` 2D e aplicado como `CanvasTexture` num plano 3D (`xrBhorModel/scene.ts:122-156`) — técnica clássica de UI diegética.

---

## 11. Pipeline de visão computacional (MediaPipe)

### 11.1 Fluxo de dados

```
Webcam ──getUserMedia──▶ <video> (espelhado via CSS scaleX(-1))
                            │  a cada frame (rAF):
                            ▼
          HandLandmarker.detectForVideo(video, performance.now())
          (rede neural, WASM + delegate GPU, runningMode VIDEO, 1 mão)
                            │  21 landmarks normalizados [0,1]
                            ▼
          gestures.ts: extrai polegar(4), indicador(8), punho(0), MCP médio(9)
            ratio = dist(4,8) / dist(0,9)          ← invariante à distância da câmera
            histerese: entra < 0.35, sai > 0.45    ← evita "tremida"
            ponto = média(4,8) → espelha X → NDC [-1,1]
                            │  PinchState {tracking, pinching, x, y}
                            ▼
          scene.ts updatePinch(): Raycaster.setFromCamera(ndc)
            ├─ pele fechada + pinça na incisão → abre
            ├─ pele aberta + pinça num órgão   → arrasta (plano z constante)
            └─ solta longe do corpo            → extrai para a bandeja
```

### 11.2 Decisões que merecem destaque

- **Normalização pela escala da mão** (`handScale = |punho − MCP do médio|`): a distância polegar–indicador em pixels varia com a distância até a câmera; dividindo pelo tamanho da mão o limiar fica estável. É uma escolha de engenharia de *features* simples e eficaz.
- **Histerese**: dois limiares (0,35 para fechar, 0,45 para abrir) formam um *Schmitt trigger* — evita que ruído do detector alterne o estado a cada frame.
- **Espelhamento**: o vídeo é exibido em modo selfie, então `x = (1 − midX)·2 − 1` alinha o gesto com o que o usuário vê.
- **Entrada desacoplada**: a cena não sabe se a pinça veio da IA ou do mouse. O mouse tem prioridade enquanto o botão está pressionado (`index.tsx:45-54`).
- **Privacidade**: inferência 100% local; nenhum quadro é enviado a servidor.

### 11.3 Limitações conhecidas

- `object-fit: cover` no vídeo corta as bordas quando a proporção da câmera difere da área de exibição, mas as coordenadas do MediaPipe são do frame inteiro → leve desalinhamento cursor × mão em telas muito largas/estreitas.
- `detectForVideo` roda a cada rAF mesmo sem frame novo de vídeo; poderia usar `video.requestVideoFrameCallback` para economizar processamento.
- Modelo e WASM vêm de CDN (ver seção 4).

---

## 12. Navegação, registro de experimentos e tema

### 12.1 Navegação

Não há biblioteca de roteamento. `App.tsx` mantém `const [page, setPage] = useState<Page>(pageFromHash)` e uma cadeia de `if (page === '...') return <Componente/>`. O tipo `Page` é derivado do array `PAGES` (`as const`), então o TypeScript garante que só ids válidos são usados.

**Roteamento por hash + History API** (desde 02/10/2026): cada página tem URL própria (`#/home`, `#/simple-pendulum`…).

- `navigate(p)` → `history.pushState({clara: true}, '', '#/p')` + `setPage(p)`: cria uma entrada no histórico do navegador.
- Evento `popstate` (botão voltar/avançar do navegador ou edição manual da URL) → `setPage(pageFromHash())`. A troca de página desmonta o experimento, então o `dispose()` da cena roda normalmente.
- `goBack(fallback)` (botão "Voltar" do site): se a entrada atual foi criada pela aplicação (`history.state.clara`), chama `history.back()`, mantendo o histórico coerente com o botão do navegador; se o usuário chegou por link direto, faz `replaceState` para o `fallback`.
- Hash em vez de caminho (`/CLARA.js/home`) porque o GitHub Pages não redireciona rotas desconhecidas para o `index.html`: um F5 em `/CLARA.js/home` daria 404.

Antes disso, a página era só um `useState`: o navegador não sabia que houve navegação, o histórico tinha uma única entrada e o botão voltar do navegador saía do site.

```
          ┌─────────┐ galeria ┌──────┐  clica card  ┌──────────────┐
 start ──▶│ select  │────────▶│ home │─────────────▶│ <experimento>│
          └────┬────┘         └──┬───┘◀── onBack ───└──────────────┘
               │ museu           │ menu
               ▼                 ▼
          ┌──────────┐      ┌──────────┐
          │  museu   │      │  sobre   │   (sobre = About.tsx)
          └──────────┘      └──────────┘
   (#/museu = Museu Virtual; as salas interativas são fases dentro dele, sem rota própria)
```

Consequência que permanece: todo experimento é importado estaticamente → bundle único > 500 kB (D8).

### 12.2 Registro (`registry.ts`)

`SimulationMeta { id, title, description, category, available, thumbnail? }`. A `Home` filtra por categoria e texto e separa `available` de "Em breve". Há 3 entradas `available: false` (Divisão Celular, Replicação do DNA, Potencial de Ação).

**Inconsistência estrutural**: o registro guarda metadados, mas o mapeamento id → componente está em `App.tsx`. Adicionar um experimento exige editar dois lugares e manter os ids sincronizados manualmente (débito D6).

### 12.3 Tema

- `index.css` define tokens (`--bg`, `--text`, `--accent-*`) em `:root` (escuro) e `.light` (claro); `App.tsx` alterna a classe no `<html>`.
- As páginas usam `var(--token)` em `style={{}}`.
- As cenas Three.js **não leem CSS**; cada `index.tsx` mantém um objeto `c` com as cores em hexadecimal para cada tema e passa `c.sceneBg` à cena. Isso duplica a paleta em ~8 arquivos.
- Experimentos XR/AR e Dissecação ignoram o tema (sempre escuros).

---

## 13. Gerenciamento de recursos de GPU

O *garbage collector* do JavaScript libera os objetos JS, mas **não** os buffers, texturas e programas alocados na GPU por WebGL. O Three.js exige `geometry.dispose()`, `material.dispose()`, `texture.dispose()` e `renderer.dispose()`.

Estratégias encontradas no projeto:

| Estratégia | Onde | Comentário |
|---|---|---|
| Lista de descartáveis (`disposables[]`) | DNA, DNA XR/AR, Dissecação (`track()`) | Robusta; recomendada como padrão |
| Geometria/material compartilhado entre meshes | Bohr (nucleonGeo, electronGeo), DNA (sphereGeo) | Reduz alocação; descartado só no `dispose` final |
| `scene.traverse` no `dispose` | Sistema Solar, Geometria Molecular | Genérica; pega tudo que está na cena |
| `clearGroup()` com dispose de geometria | Projétil | OK |
| `group.clear()` **sem** dispose | Bohr desktop (`buildOrbitAndElectrons`) | **Vazamento**: a geometria de cada órbita é recriada a cada `update` e nunca liberada (débito D2) |

Outros recursos liberados no `dispose`: `cancelAnimationFrame`/`setAnimationLoop(null)`, `ResizeObserver.disconnect()`, `OrbitControls.dispose()`, `renderer.domElement.remove()` (cenas que criam o canvas), `MediaStream.getTracks().stop()` e `landmarker.close()` (Dissecação).

---

## 14. Catálogo de experimentos

| id (`registry.ts`) | Pasta | Área | Modalidade | Modelo | LOC (idx+scene+phys) |
|---|---|---|---|---|---|
| `simple-pendulum` | `physics/Pendulum` | Física | Desktop | EDO não linear, Euler semi-implícito | 125+142+35 |
| `projectile-motion` | `physics/Projectile` | Física | Desktop | Cinemática analítica + máquina de estados | 151+277+48 |
| `planetary-motion` | `physics/SolarSystem` | Física | Desktop | Órbitas circulares paramétricas | 110+204+51 |
| `mechanical-waves` | `physics/Waves` | Física | Desktop | Onda progressiva `A·sin(kx−ωt)` em malha | 120+125+30 |
| `bohr-model` | `chemistry/BohrModel` | Química | Desktop | Bohr: r ∝ n², ω ∝ 1/n³ | 228+257+70 |
| `xr-bohr-model` | `chemistry/xrBhorModel` | Química | VR | reutiliza `BohrModel/physics` | 143+299 |
| `ar-bohr-model` | `chemistry/arBohrModel` | Química | AR | reutiliza `BohrModel/physics` | 138+251 |
| `molecular-geometry` | `chemistry/MolecularGeometry` | Química | Desktop | VSEPR (7 geometrias) | 135+151+194 |
| `dna-helix` | `biology/DnaHelix` | Biologia | Desktop | Hélice paramétrica B-DNA | 136+160+55 |
| `xr-dna-helix` | `biology/xrDnaHelix` | Biologia | VR | hélice duplicada, escala 2,5× | 135+259 |
| `ar-dna-helix` | `biology/arDnaHelix` | Biologia | AR | hélice duplicada, escala de sala | 130+210 |
| `frog-dissection` | `biology/FrogDissection` | Biologia | Gestos | Máquina de estados + raycasting | 236+315+77 (gestures) |

> Observação: a pasta `xrBhorModel` tem erro de grafia ("Bhor"). Renomear exige atualizar o import em `App.tsx`.

---

## 15. Atributos de qualidade (ISO/IEC 25010)

Sugestão de tabela para a monografia, com cenários no estilo ATAM:

| Atributo | Cenário | Mecanismo arquitetural | Situação atual |
|---|---|---|---|
| **Portabilidade** | Usuário abre o site num celular, PC ou headset | Padrões Web (WebGL/WebXR), sem instalação | ✔ Atendido; XR depende do navegador |
| **Manutenibilidade / Modificabilidade** | Dev adiciona um experimento novo | Contrato de cena + registro | ◐ 3 arquivos + 2 edições; registro dividido |
| **Reusabilidade** | Mesmo modelo em VR e AR | `physics.ts` sem dependências | ◐ Bohr sim, DNA não |
| **Testabilidade** | Verificar a física sem GPU | Funções puras | ◐ Possível, mas não há nenhum teste |
| **Eficiência de desempenho** | Manter 60 FPS (90 em VR) | Geometria compartilhada, dt com teto, render fora do React | ✔ Em geral; Ondas recalcula normais de ~7,5 mil vértices por frame |
| **Usabilidade** | Aluno sem mouse/controle interage | Gestos + fallback de mouse | ✔ Na Dissecação |
| **Confiabilidade / Tolerância a falhas** | Câmera negada ou CDN fora | Fallback com mensagem | ✔ Dissecação; XR mostra "not supported" |
| **Segurança / Privacidade** | Vídeo do aluno | Inferência local, HTTPS | ✔ |
| **Uso de recursos** | Entrar e sair de experimentos várias vezes | `dispose()` | ◐ Vazamento no Bohr desktop |

---

## 16. Débitos técnicos e problemas encontrados

Encontrados na leitura do código; nenhum foi corrigido (só documentado).

| Id | Severidade | Problema | Onde |
|---|---|---|---|
| D1 | Média | Ao trocar o tema, a cena é recriada com `DEFAULTS`, mas os sliders mantêm o valor anterior → UI e 3D dessincronizados | `index.tsx` de Pêndulo, Ondas, Projétil, Sistema Solar, DNA |
| D2 | ~~Média~~ **Resolvido (06/10/2026)** | Bohr desktop: `orbitsGroup.clear()` não libera as geometrias das órbitas a cada `update` (vazamento de GPU) | `BohrModel/scene.ts:135-167` |
| D3 | Média (parcial; **parte AR resolvida em 06/10/2026**, seção 23 — resta a variante VR do DNA e do Bohr) | DNA XR/AR reimplementam a hélice em vez de usar `DnaHelix/physics.ts`; ~~tabela de elementos copiada 3×~~ (resolvido em 06/10/2026: `BohrModel/elements.ts`); construção do átomo ainda duplicada nas variantes XR/AR | `xrDnaHelix/scene.ts:132`, `arDnaHelix/scene.ts:124`, `*Bohr*` |
| D4 | ~~Média~~ **Resolvido (06/10/2026, seção 23)** | AR: `ARButton.createButton(renderer)` sem `domOverlay` → o próprio ARButton cria um overlay só com o botão "X"; os sliders/selects do React **não aparecem durante a sessão AR** (o comentário em `arDnaHelix/scene.ts:19` diz o contrário). Verificar em aparelho | `arBohrModel/scene.ts:66`, `arDnaHelix/scene.ts:53` |
| D5 | Baixa | DNA XR: `drawLabel` usa `14` fixo em vez de `bp` para posicionar o painel; com 30 pares o painel fica dentro da hélice | `xrDnaHelix/scene.ts:111` |
| D6 | Média | Registro dividido: metadados em `registry.ts`, mapeamento id→componente em `App.tsx` | `App.tsx:20-75` |
| D7 | ~~Baixa~~ **Resolvido (02/10/2026)** | Sem roteamento por URL: o botão voltar do navegador saía do site. Corrigido com roteamento por hash + History API (ver 12.1) | `App.tsx` |
| D8 | Baixa | Bundle único > 500 kB (sem `React.lazy`/code splitting) | `App.tsx` imports |
| D9 | Baixa | Estatística "7 simulações disponíveis" fixa no código; existem 12 | `Home.tsx` (~linha 330) |
| D10 | Baixa | Código morto: `components/ui/ExperimentCard.tsx` e `ExperimentDetails.tsx` (copiados de um template de cursos) | `components/ui/` |
| D11 | Baixa | `index.html`: `<title>frontend</title>` e `lang="en"` | `frontend/index.html` |
| D12 | Baixa | Proxy `/api` remanescente do backend removido | `vite.config.ts` |
| D13 | ~~Baixa~~ **Resolvido (06/10/2026)** | As páginas "Modo Imersivo" e "Sobre" eram placeholders "Hello, world!"; viraram o Museu Virtual e a página Sobre (`pages/About.tsx`); `Placeholder.tsx` foi removido | `pages/Placeholder.tsx` |
| D14 | Média | Nenhum teste automatizado (o README diz que a física é "testável isoladamente", mas não há runner configurado) | — |
| D15 | Baixa | Dissecação: comentário diz que extrai se `x > EXTRACT_X` (1,55), mas o código usa `EXTRACT_X − 0.5` (1,05) | `FrogDissection/scene.ts:279` |
| D16 | Baixa (resolvido nos experimentos novos via `coverMapping` em 06/10/2026; continua na Dissecação) | Dissecação: desalinhamento cursor × mão com `object-fit: cover` (seção 11.3) | `FrogDissection/index.tsx:128` |
| D17 | Baixa | XR: controlador 0/1 assumido como direita/esquerda | cenas XR/AR |
| D18 | Baixa | Descrição do Sistema Solar em `registry.ts` fala em "falloff gravitacional" da luz — o decaimento da `PointLight` não tem relação com gravidade | `registry.ts:56` |
| D19 | ~~Baixa~~ **Resolvido (06/10/2026, via `hostInPage`)** | Bohr desktop usava `setPixelRatio(window.devicePixelRatio)` sem limite (as demais limitam a 2) — custo alto em telas 3× | `BohrModel/scene.ts:66` |
| D20 | Baixa | Paleta de cores duplicada em cada `index.tsx` (objeto `c`) | todos os `index.tsx` desktop |
| D21 | Baixa | Dissecação: após `reset()`, o loop religa `visible = true` nos órgãos enquanto a pele fecha e nunca desliga | `FrogDissection/scene.ts:307-309` |
| D22 | Baixa (**resolvido no AR** em 06/10/2026; continua na variante VR) | DNA AR/VR centralizados em y = 0 do `local-floor` (chão): metade da hélice fica abaixo do piso | `xrDnaHelix/scene.ts:25`, `arDnaHelix/scene.ts:30` |

---

## 17. Sugestões de figuras e diagramas para o TCC2

Ferramentas sugeridas: **draw.io / diagrams.net** (geral), **Mermaid** (`mermaid.live` — rápido, exporta SVG/PNG), **PlantUML** (UML formal), **Structurizr/C4-PlantUML** (modelo C4), **Excalidraw** (estilo esboço). Para capturas: DevTools do Chrome (modo dispositivo) e gravação de tela do headset/celular.

### Figura 1 — Diagrama de Contexto (C4 nível 1)
**Mostra**: o sistema CLARA.js como uma caixa; atores: Aluno, Professor, Desenvolvedor; sistemas externos: GitHub Pages, CDN jsDelivr, Google Storage (modelo MediaPipe), runtime WebXR do dispositivo.
**Onde usar**: capítulo de Visão Geral da Arquitetura.

```mermaid
flowchart LR
  aluno([Aluno / Professor]) -->|HTTPS, navegador| clara[CLARA.js<br/>SPA de laboratório virtual]
  dev([Desenvolvedor]) -->|git push| gh[GitHub + Actions]
  gh -->|deploy estático| pages[GitHub Pages]
  pages -->|serve bundle| clara
  clara -->|WASM| cdn[jsDelivr CDN]
  clara -->|modelo .task| gcs[Google Cloud Storage]
  clara -->|WebXR Device API| xr[Runtime XR<br/>headset / ARCore]
  clara -->|getUserMedia| cam[Webcam]
```

### Figura 2 — Diagrama de Contêineres/Componentes (C4 níveis 2–3)
**Mostra**: dentro do navegador: App (React), Páginas, Registro, Módulos de Experimento (cada um com `index`/`scene`/`physics`), bibliotecas (Three.js, MediaPipe), APIs do navegador (WebGL, WebXR, MediaDevices).

### Figura 3 — Arquitetura em camadas (a figura principal do trabalho)
**Mostra**: as 5 camadas da seção 6.1 empilhadas, com setas de dependência apontando para baixo e o domínio na base. Destaque visual (cor) para "Domínio independente de tecnologia".
**Dica**: faça uma versão genérica e outra "instanciada" com o Pêndulo (`PendulumSimulation` → `createPendulumScene` → `stepPendulum`).

### Figura 4 — Anatomia de um módulo de experimento
**Mostra**: a pasta de um experimento com os 3 arquivos, o que cada um importa e o que exporta. Diagrama de classes UML (mesmo sem classes, use estereótipos `«function»`, `«interface»`).

```mermaid
classDiagram
  class PendulumSimulation {
    «React component»
    +onBack()
    +theme
    -canvasRef
    -sceneRef
    -L, g, theta0 : state
  }
  class PendulumScene {
    «interface»
    +update(cfg)
    +dispose()
  }
  class createPendulumScene {
    «factory»
    +(canvas, cfg, bg) PendulumScene
  }
  class physics {
    «pure module»
    +stepPendulum(state, cfg, dt) PendulumState
    +period(cfg) number
  }
  PendulumSimulation --> createPendulumScene : cria
  PendulumSimulation --> PendulumScene : guarda em useRef
  createPendulumScene ..|> PendulumScene : retorna
  createPendulumScene --> physics : chama a cada frame
  PendulumSimulation --> physics : period() p/ exibir
```

### Figura 5 — Diagrama de sequência do ciclo de vida
**Mostra**: a sequência da seção 8.2 (montar → loop → update → dispose). Excelente para explicar por que React e Three.js convivem sem conflito.

```mermaid
sequenceDiagram
  actor U as Usuário
  participant A as App.tsx
  participant I as index.tsx
  participant S as scene.ts
  participant P as physics.ts
  U->>A: clica no card
  A->>I: render (setPage)
  I->>S: createXScene(canvas, DEFAULTS)
  S-->>I: { update, dispose }
  loop cada frame (rAF / XR)
    S->>P: step(state, cfg, dt)
    P-->>S: novo estado
    S->>S: renderer.render()
  end
  U->>I: move slider
  I->>S: update(cfg)
  U->>I: Voltar
  I->>A: onBack()
  A->>I: unmount
  I->>S: dispose()
```

### Figura 6 — Reuso do domínio entre modalidades
**Mostra**: `BohrModel/physics.ts` no centro, com três setas para as cenas desktop/VR/AR, cada uma anotada com escala e posição (seção 10.2). Ao lado, as três capturas de tela correspondentes.

### Figura 7 — Matriz de modalidades
**Mostra**: a tabela da seção 10.1 como figura (ícones de monitor, headset, celular, mão). Pode virar uma tabela formal da monografia.

### Figura 8 — Pipeline de visão computacional
**Mostra**: webcam → vídeo → HandLandmarker → 21 landmarks → razão pinça/escala → histerese → NDC → raycaster → ação. Inclua a imagem oficial dos 21 *landmarks* da mão do MediaPipe (com os pontos 0, 4, 8, 9 destacados).

```mermaid
flowchart LR
  cam[Webcam] --> vid["&lt;video&gt; espelhado"]
  vid --> hl[HandLandmarker<br/>WASM + GPU]
  hl --> lm[21 landmarks]
  lm --> r["ratio = d(4,8) / d(0,9)"]
  r --> h{Histerese<br/>0,35 / 0,45}
  h --> ps["PinchState<br/>{tracking, pinching, x, y}"]
  mouse[Mouse/touch] --> ps
  ps --> rc[Raycaster]
  rc --> fsm[Máquina de estados<br/>da dissecação]
```

### Figura 9 — Gráfico da histerese da pinça
**Mostra**: eixo X = tempo, eixo Y = `ratio`; duas linhas horizontais (0,35 e 0,45) e o estado `pinching` (0/1) abaixo. Explica visualmente por que não há "tremida". Pode ser gerado com dados reais logando `ratio` no console.

### Figura 10 — Máquinas de estado
- **Dissecação**: `Fechado → (pinça na incisão) → Aberto → (pinça no órgão) → Arrastando → (solta em x>1,05) → Extraído | (solta antes) → Aberto`.
- **Projétil**: `idle → (Disparar) → flying → (y ≤ 0) → landed → (Resetar) → idle`; qualquer slider → `idle`.

```mermaid
stateDiagram-v2
  [*] --> Fechado
  Fechado --> Aberto: pinça sobre a incisão
  Aberto --> Arrastando: pinça sobre órgão
  Arrastando --> Aberto: solta com x ≤ 1,05 (volta pra casa)
  Arrastando --> Aberto: solta com x > 1,05 (extrai → bandeja)
  Aberto --> Fechado: Reiniciar
```

### Figura 11 — Diagrama de navegação
**Mostra**: o diagrama da seção 12.1 (estados de página do `App.tsx`).

### Figura 12 — Diagrama de implantação (UML Deployment)
**Mostra**: nós "Máquina do desenvolvedor", "GitHub Actions runner", "GitHub Pages", "CDNs", "Dispositivo cliente" (com sub-nós GPU, runtime XR, câmera). Base: seção 4.

### Figura 13 — Sistemas de coordenadas e escala em XR
**Mostra**: um boneco de 1,6 m; o átomo VR a 4 m à frente com camada 1 de 2 m de raio (o usuário fica dentro do átomo); o átomo AR a 1,5 m com camada 1 de 30 cm. Explica a decisão de escala por modalidade.

### Figura 14 — Fluxo "como adicionar um experimento"
**Mostra**: passo 1 criar pasta (3 arquivos) → passo 2 registrar em `registry.ts` → passo 3 importar em `App.tsx`. Usar para discutir extensibilidade (e a melhoria de unificar 2 e 3).

### Figura 15 — Galeria de capturas de tela
Uma prancha 3×4 com os 12 experimentos, legendados com área e modalidade. Para VR, use a captura do próprio headset (Quest: botão Meta + gatilho) ou o emulador **Immersive Web Emulator** (extensão do Chrome).

### Figura 16 — Gráficos de avaliação (se fizer a avaliação da seção 2.4)
- Barras: FPS médio por experimento × dispositivo.
- Barras empilhadas: LOC por camada (physics/scene/index) por experimento — mostra visualmente a separação de responsabilidades.
- Antes × depois da refatoração do DNA (linhas duplicadas eliminadas).
- Linha: período real (simulado) × período pela fórmula de pequenos ângulos, em função de θ₀ (valida o integrador).

---

## 18. Roteiro sugerido de evolução para o TCC2

Ordenado por retorno para a monografia (quanto ajuda a sustentar a contribuição arquitetural):

1. **Unificar o registro** (D6): `registry.ts` passa a conter também `component: React.lazy(() => import(...))`. `App.tsx` vira genérico. Resolve D6 e D8 de uma vez e reduz o custo de adicionar experimento para "1 pasta + 1 entrada".
2. **Extrair um "kit" comum de cena** (`src/core/`): `createRenderer`, `attachResize`, `createLoop(dt clamp)`, `DisposableBag`. Hoje cada `scene.ts` repete ~30 linhas de boilerplate. Isso transforma a convenção em **framework**, o que fortalece o argumento de arquitetura.
3. **Domínio único por fenômeno** (D3): DNA XR/AR importam `DnaHelix/physics.ts` com parâmetros de escala; tabela de elementos em um só arquivo.
4. **Testes do domínio** (D14): Vitest para `physics.ts` (ex.: conservação de energia do pêndulo, alcance máximo em 45°, ângulos VSEPR via produto escalar). Gera métrica de cobertura.
5. **Roteamento por URL** (D7): `#/simple-pendulum` com `hashchange` (compatível com GitHub Pages sem configuração extra).
6. **Passo de tempo fixo** no Pêndulo e eventuais novos integradores.
7. **Abstração de entrada genérica**: generalizar `PinchState` para uma interface `InputSource` usada também pelos controles XR (o gesto de pinça também existe no *hand tracking* do WebXR — `XRHand`). Isso amplia o argumento C4.
8. ~~Implementar o "Museu Virtual" (hoje placeholder)~~ — feito: virou o **Museu Virtual** (seção 21, A4–A7).
9. **Corrigir D4** passando `{ optionalFeatures: ['dom-overlay'], domOverlay: { root: elemento } }` ao `ARButton`.
10. **Auto-hospedar o MediaPipe** (WASM e `.task` em `public/`) para funcionar offline/sem CDN.

---

## 19. Métricas do código (baseline)

Medido com `wc -l` em `frontend/src` (commit `cee8aa7`):

| Grupo | Arquivos | Linhas |
|---|---|---|
| Núcleo da aplicação (`main`, `App`, `index.css`) | 4 | 170 |
| Páginas | 3 | 818 |
| Componentes não usados | 2 | 242 |
| Registro | 1 | 116 |
| Física (4 experimentos) | 12 | 1.418 |
| Química (4 pastas) | 10 | 1.866 |
| Biologia (4 pastas) | 10 | 1.713 |
| **Total** | **42** | **6.343** |

Dependências de runtime: 4 (`react`, `react-dom`, `three`, `@mediapipe/tasks-vision`). Backend: nenhum. Histórico: 13 commits (jun–set/2026).

---

## 20. Referências sugeridas

Confira os dados bibliográficos antes de citar.

- **Design Science Research** — HEVNER, A. R. et al. *Design Science in Information Systems Research*. MIS Quarterly, 2004. (metodologia: artefato + avaliação)
- **Arquitetura de software** — BASS, L.; CLEMENTS, P.; KAZMAN, R. *Software Architecture in Practice*. Addison-Wesley. (atributos de qualidade, ATAM)
- **Modelo C4** — BROWN, Simon. *The C4 model for visualising software architecture* (c4model.com).
- **Qualidade de produto** — ISO/IEC 25010 — *Systems and software Quality Requirements and Evaluation (SQuaRE)*.
- **WebXR** — W3C. *WebXR Device API* (Candidate Recommendation) e *WebXR Augmented Reality Module*.
- **MediaPipe** — LUGARESI, C. et al. *MediaPipe: A Framework for Building Perception Pipelines*. arXiv, 2019.
- **MediaPipe Hands** — ZHANG, F. et al. *MediaPipe Hands: On-device Real-time Hand Tracking*. arXiv, 2020.
- **Laboratórios virtuais (trabalhos relacionados)** — PhET Interactive Simulations (Universidade do Colorado); buscar também por "virtual laboratory WebXR", "web-based virtual lab architecture", "gesture-based virtual dissection".
- **Game loop** — FIEDLER, Glenn. *Fix Your Timestep!* (gafferongames.com) — base para a discussão de passo de tempo.
- **Integradores simpléticos** — HAIRER, E.; LUBICH, C.; WANNER, G. *Geometric Numerical Integration*. Springer. (justifica o Euler semi-implícito)
- **Clean Architecture** — MARTIN, Robert C. *Clean Architecture*. Prentice Hall. (regra de dependência)

---

## 21. Diário de argumentos concretos (registro vivo)

> Esta seção é alimentada **durante o desenvolvimento do TCC2**. Cada vez que uma mudança no código gerar uma evidência a favor (ou contra) da tese "a arquitetura é a contribuição", ela entra aqui, com data, o que mudou, a evidência mensurável e como usar na monografia. A ideia é que, na hora de escrever os capítulos de Resultados e Discussão, os argumentos já estejam coletados e com números.

Modelo de entrada:

```
### A<n> — <título> (<data>)
- Mudança: o que foi feito e onde.
- Evidência: número/fato verificável (linhas, arquivos tocados, tempo, FPS…).
- Atributo de qualidade: (ISO 25010) qual atributo isso demonstra.
- Como usar na monografia: em que capítulo/figura entra e qual frase sustenta.
```

### A1 — Roteamento por hash sem biblioteca (02/10/2026)

- **Mudança**: `App.tsx` passou de `useState` puro para roteamento por hash + History API (`pushState`/`popstate`). Resolve o débito D7: o botão voltar do navegador fechava o site.
- **Evidência**: 1 arquivo alterado; nenhuma dependência nova; nenhum experimento precisou ser modificado. Ganhou de brinde: link direto para cada experimento, F5 preservando a tela, botão avançar.
- **Atributo de qualidade**: Modificabilidade (a navegação estava concentrada num ponto só); Usabilidade.
- **Como usar**: exemplo de que o isolamento dos experimentos (eles só recebem `onBack`/`theme`) permite trocar a infraestrutura de navegação sem tocar no domínio. Também justifica a escolha *hash* vs *path* pela restrição da hospedagem estática (GitHub Pages).

### A2 — Moldura comum dos experimentos: `ExperimentShell` (05/10/2026)

- **Mudança**: criado `src/components/ExperimentShell/` (`ExperimentShell.tsx` 191 linhas + `ExperimentShell.css` 235 linhas). Ele envolve qualquer experimento e sobrepõe os botões **Teoria**, **Como foi feito** e **Voltar**, e um painel responsivo (lateral no desktop, *bottom sheet* no celular). O botão "Voltar", que estava copiado nos 12 `index.tsx`, foi removido de todos e passou a existir em um só lugar.
- **Evidência**:
  - Os 12 componentes de experimento só **perderam** código: `12 files changed, 17 insertions(+), 215 deletions(-)`. Nenhuma linha de `physics.ts` ou `scene.ts` foi tocada.
  - Uma funcionalidade nova (2 botões + painel de conteúdo) chegou aos 12 experimentos e às 4 modalidades (desktop, VR, AR, gestos) com **uma** implementação.
  - O contrato do componente de experimento ficou menor: de `{ onBack, theme }` para `{ theme }` (ou nenhuma prop, nos XR/AR/gestos).
  - `App.tsx` trocou 12 `if`s por uma tabela `EXPERIMENTS` (id → render), dando um passo na direção do débito D6 (registro unificado).
- **Atributo de qualidade**: Manutenibilidade/Modificabilidade (DRY, ponto único de mudança), Reusabilidade, Usabilidade.
- **Como usar**: é o padrão *Decorator*/*Template* aplicado à camada de apresentação: a "moldura" é infraestrutura que todo experimento recebe de graça, sem saber que ela existe. Bom para uma figura "antes × depois" (12 botões duplicados → 1 componente) e para a tabela de extensibilidade: custo de adicionar um recurso transversal a todos os experimentos = 1 componente novo + remoções.

### A3 — Documentação como parte do módulo, carregada sob demanda (05/10/2026)

- **Mudança**: cada pasta de experimento passou a ter um `teoria.md` (texto para o aluno) além do `README.md` (técnico). O `registry.ts` ganhou os campos `folder` e `theoryFolder`. A moldura carrega o Markdown com `import.meta.glob(..., { query: '?raw' })` **sem `eager`** e o renderiza com `marked` (nova dependência, sem dependências transitivas).
- **Evidência**:
  - O build gera **um chunk por arquivo `.md`** (12 READMEs entre 3,3 e 12,6 kB): o conteúdo só é baixado quando o aluno abre a aba. O bundle principal não carrega os textos.
  - As variantes VR/AR **reaproveitam a teoria** do experimento base via `theoryFolder` (6 variantes → 0 textos duplicados), o mesmo princípio de reuso do domínio entre modalidades (C3) aplicado ao conteúdo.
  - A mesma fonte (`README.md`) serve a dois públicos: o desenvolvedor no repositório e o aluno no site ("Como foi feito").
- **Atributo de qualidade**: Eficiência de desempenho (carregamento sob demanda), Manutenibilidade (documentação mora junto do código que descreve), Reusabilidade.
- **Como usar**: reforça a ideia de que o **módulo de experimento é autocontido** (domínio + cena + UI + documentação na mesma pasta), o que deixa adicionar um experimento previsível. Também é o primeiro exemplo de *code splitting* no projeto (o débito D8 continua para os experimentos em si).

### A4 — Museu Virtual (museu em 1ª pessoa) gerado a partir do registro (06/10/2026)

- **Mudança**: o placeholder "Museu Virtual" virou um museu 3D em primeira pessoa (`src/museum/`): o aluno anda com WASD + mouse (`PointerLockControls`), cada parede é uma área do conhecimento e cada porta leva a um experimento (tecla E). Ao voltar do experimento, o aluno reaparece na frente da porta por onde saiu. O módulo segue a **mesma convenção em 3 camadas** dos experimentos:
  - `layout.ts` (183 linhas) — domínio puro: planta da sala, posição das portas, colisão (parede + obstáculo circular), porta mais próxima, ponto de nascimento;
  - `scene.ts` (313 linhas) — Three.js: transforma a planta em paredes, portas, placas (`CanvasTexture`) e trata a entrada;
  - `index.tsx` (156 linhas) — React: instruções, aviso "E · Entrar em…", integração com a navegação.
- **Evidência**:
  - **Zero arquivos de experimento alterados** (`git diff -- src/simulations` vazio). O museu reaproveita a mesma navegação (`navigate`/`goBack`) e a mesma moldura (`ExperimentShell`) que a galeria usa.
  - As 12 portas são **geradas do `registry.ts`**: o mesmo registro alimenta duas interfaces distintas (galeria 2D e museu 3D). Um experimento novo ganha porta automaticamente; a sala cresce para caber (largura/profundidade calculadas pelo número de portas por parede).
  - `layout.ts` foi verificado fora do navegador (Node, sem GPU): 12 entradas → sala de 20,4 × 20,4 m, 4 portas por parede, colisão e detecção de porta corretas. Isso só é possível porque o domínio não depende do Three.js.
  - O loop usa `renderer.setAnimationLoop` desde já, preparando as etapas VR/AR sem reescrever o laço.
- **Atributo de qualidade**: Modificabilidade/Extensibilidade (nova interface sem tocar nos módulos existentes), Reusabilidade (registro, navegação e moldura reaproveitados), Testabilidade (domínio do museu executável sem GPU).
- **Como usar**: mostra que a separação domínio × renderização × UI não é só uma convenção dos experimentos, mas um **padrão replicável** para novos tipos de módulo. Boa figura: o `registry.ts` no centro com duas setas — "Galeria (Home.tsx)" e "Museu (museum/)" — e as duas convergindo para os mesmos 12 experimentos.

### A5 — Joystick de toque: segunda fonte de entrada para a mesma cena (06/10/2026)

- **Mudança**: o museu ganhou controles de celular (`src/museum/TouchControls.tsx`, 125 linhas): joystick virtual analógico no canto inferior esquerdo, arrastar o dedo para olhar e um botão "Toque para entrar" na porta próxima. Na cena (`scene.ts`), teclado e joystick passaram a produzir **o mesmo vetor (frente, lado)** antes da lógica de movimento; a API da cena ganhou `setTouchMove`, `touchLook` e `enterNearest`.
- **Evidência**:
  - `layout.ts` (colisão, portas, planta) **não foi alterado**: o domínio é indiferente à origem da entrada.
  - Os dois dedos funcionam ao mesmo tempo (andar + olhar) porque cada controle captura o próprio `pointerId` (Pointer Events + `setPointerCapture`), sem biblioteca de joystick.
  - É a **segunda ocorrência** do padrão de abstração de entrada do projeto: a Dissecação já unificava MediaPipe e mouse num `PinchState`; o museu unifica teclado e toque num vetor de movimento. Duas ocorrências independentes indicam que é um padrão da arquitetura, não um acaso.
- **Atributo de qualidade**: Portabilidade (mesma experiência em desktop e celular), Modificabilidade (nova entrada sem tocar no domínio), Usabilidade.
- **Como usar**: reforça o argumento C4 (abstração de entrada independente de dispositivo). Próximo passo natural: a mesma abstração receber os controles VR (WebXR), fechando o ciclo teclado/toque/controle VR → um único "vetor de intenção".

> **Nota conceitual para a monografia (classificação das modalidades).** No contínuo realidade-virtualidade de Milgram e Kishino (1994), o museu em desktop/celular é **realidade virtual não imersiva** (*desktop VR*): ambiente totalmente virtual visto por uma tela comum. As variantes `xr*` são **realidade virtual imersiva** (headset com rastreamento de cabeça) e as `ar*` são **realidade aumentada**. A diferença entre o museu na tela e no óculos não é a posição no contínuo, e sim o **grau de imersão**. Hoje, entrar numa porta leva a uma página 2D com painel HTML, o que **quebra a imersão**; a direção proposta é cada experimento ganhar também uma forma "sala", montada dentro do museu com **interface diegética** (controles 3D dentro do mundo), reutilizando o mesmo `physics.ts`. Isso depende da etapa 3 (contrato de cena "montar num grupo").

### A6 — Contrato montável + sala interativa em 4 experimentos (06/10/2026)

- **Mudança**: implementada a seção 22 para Pêndulo, Geometria Molecular, DNA e Bohr. Cada `scene.ts` virou um módulo montável (`core/mountable.ts`) e a página passou a ser só mais um hospedeiro (`core/hostInPage.ts`). Cada um ganhou um `sala.ts` com as regras de uma sala no Museu Virtual: controles em camadas (HUD automático + interação direta opcional) e entrada por troca de fase com transição. Detalhes em 22.7 e 22.8.
- **Evidência**:
  - **0 linhas** alteradas nos 4 `physics.ts`; **0 linhas** nos `index.tsx` de Pêndulo, Geometria Molecular e DNA (o do Bohr só trocou a tabela local por um `import`). A mesma física e a mesma página continuam funcionando, agora sobre outro hospedeiro.
  - Os 4 `scene.ts` somavam 710 linhas e passaram a 641 (−69), com 102 linhas de infraestrutura que antes se repetiam em cada um agora concentradas em `hostInPage.ts`.
  - Dar uma sala a um experimento custou **29 a 71 linhas** (`sala.ts`), sem tocar no museu: as salas são descobertas por `import.meta.glob`.
  - A migração **pagou dívida técnica**: D2 (vazamento de GPU no Bohr) e D19 (pixel ratio sem limite) resolvidos, e a tabela de elementos copiada em 3 arquivos virou uma só (−68/+7 linhas).
  - Verificação **sem GPU**: 14 checagens automáticas no Node (montagem/descarte, subpasso do integrador, a interação de pegar o pêndulo com resultado físico conferido com a fórmula), só possível porque o conteúdo do experimento não depende mais de renderer nem de câmera.
- **Atributo de qualidade**: Reusabilidade (um conteúdo, dois hospedeiros), Modificabilidade (os dois contratos convivem; migração incremental), Testabilidade, Confiabilidade (vazamento corrigido).
- **Como usar**: é o resultado central do TCC2 — a mesma unidade de domínio aparece em duas formas de apresentação (página e mundo 3D), e cada forma em vários dispositivos. Figuras sugeridas: (1) "antes × depois" do `scene.ts` (caixa fechada com renderer/câmera/laço × módulo montável + hospedeiros); (2) a tabela 22.8 como tabela de resultados; (3) gráfico de barras com linhas por `scene.ts` antes/depois. Para a discussão, os **desvios da proposta** (22.7) mostram o ciclo de projeto → implementação → revisão do projeto, típico de Design Science Research.

### A7 — Museu só com salas interativas: decisão de produto resolvida por um filtro (06/10/2026)

- **Mudança**: após testar a sala interativa, a decisão foi que o Museu Virtual mostra **apenas** os experimentos que têm sala interativa (`sala.ts`); os demais continuam acessíveis pela galeria. A ★ que distinguia essas portas deixou de ser necessária e foi removida.
- **Evidência**:
  - A mudança foi **uma condição no filtro** que gera as portas a partir do registro (`s.available && s.id in ROOMS`), mais a remoção da ★ (3 arquivos do `museum/`). Nenhum experimento, nenhum `sala.ts` e nenhuma regra de colisão foi tocado.
  - O salão **se redimensionou sozinho**: com 4 portas (Química 2, Física 1, Biologia 1), `computeLayout` gerou um salão de 13,2 × 13,2 m em vez de 20,4 × 20,4 m.
  - Adicionar um experimento ao museu continua sendo só criar o `sala.ts` dele: a porta aparece e o salão cresce.
- **Atributo de qualidade**: Modificabilidade (mudança de requisito absorvida pelo dado, não pelo código).
- **Como usar**: exemplo de requisito que mudou depois de um teste com o produto e custou uma linha, porque a interface é **derivada** do registro em vez de escrita à mão — bom contraponto para a discussão sobre interfaces geradas a partir de dados.

### A8 — AR como terceiro hospedeiro: de cenas copiadas a ~20 linhas por experimento (06/10/2026)

- **Mudança**: as variantes AR deixaram de ser cenas próprias e passaram a usar um hospedeiro AR genérico (`src/ar/`, `hostInAR`) sobre os experimentos montáveis, com tocar para posicionar (hit-test), gestos (arrastar, pinça, girar) e ajustes durante a sessão (dom-overlay). Detalhes na seção 23.
- **Evidência**:
  - **674 linhas** de cenas AR copiadas foram removidas; cada experimento AR agora é um `ar.ts` de **20–21 linhas**, que reaproveita o conteúdo (`scene.ts`) e os controles (`sala.ts`) já existentes.
  - A **Geometria Molecular ganhou AR sem nenhuma linha de cena nova**: só a definição, uma entrada no registro e uma linha no `App.tsx`.
  - Volume total de código AR praticamente igual (674 → 665), mas agora genérico e com funcionalidades que antes não existiam.
  - Débitos D4 e D22 (no AR) resolvidos; parte AR do D3 resolvida.
  - 12 verificações automáticas da matemática dos gestos e do tamanho inicial, sem celular (seção 23.6).
- **Atributo de qualidade**: Reusabilidade, Modificabilidade, Usabilidade (padrão de interação conhecido do usuário), Portabilidade (com aviso claro onde não há suporte).
- **Como usar**: completa o argumento central — o mesmo experimento em **três hospedeiros** (página, sala interativa e AR). A tabela 23.5 e o diagrama dos três hospedeiros são candidatos fortes a figura/tabela de resultados. A comparação "antes × depois" da 23.4 mostra que a contribuição não é "menos código", e sim código **genérico**: o custo marginal de um novo experimento AR caiu de uma cena inteira para uma definição de ~20 linhas.

### A9 — Dois experimentos de webcam sobre um rastreamento de mão compartilhado (06/10/2026)

- **Mudança**: criados **"Você é o Móvel"** (Física — cinemática: gráficos x(t) e v(t) ao vivo a partir da posição da mão, calibrada em metros pela palma; desafios de repouso, MU, ida e volta e MUV com nota) e **"Lei de Boyle com as Mãos"** (Química — gás ideal 2D de partículas entre as duas mãos; pressão medida pelas colisões; gráfico P × V com a isoterma). Escolhidos após pesquisa nos conteúdos do ensino médio (BNCC, EM13CNT101) pelo critério "o corpo do aluno é o experimento". O MediaPipe saiu da Dissecação e virou módulo comum: `core/handTracking.ts` (72 linhas) + gancho `components/handInput/useHandCamera.ts` (78 linhas).
- **Evidência**:
  - **Reuso**: os dois experimentos novos e a Dissecação usam o mesmo rastreador. A Dissecação foi migrada **sem tocar** no seu `index.tsx` nem no `scene.ts` (só o `gestures.ts`: +16/−20 linhas).
  - **Terceira ocorrência** do padrão de abstração de entrada (C4): as cenas recebem `readPosition()` / `readWalls()` e não sabem se a entrada é a mão (MediaPipe) ou o mouse — depois de `PinchState` (Dissecação) e do vetor de movimento (Museu Virtual).
  - **A física emerge, não é programada**: no Boyle, a pressão medida só pelas colisões bateu com a teoria N·T/V (erros de 1,7%, 0,0% e 5,2% para V = 0,5, 1 e 2) e P·V variou 5% — a Lei de Boyle aparece da mecânica das partículas. No cinemática, a velocidade por mínimos quadrados recuperou 4,00 cm/s² num MUV simulado.
  - **Teste mudou o design**: a nota dos desafios com tolerância fixa (5 cm) dava 0 a quem fazia o MU na metade da velocidade; passou a ser proporcional à amplitude (nota 42 nesse caso).
  - **Convenção independente do motor gráfico**: os dois mantêm `physics.ts`/`scene.ts`/`index.tsx`, mas a "cena" é canvas 2D, não Three.js.
  - `coverMapping` (alinhamento vídeo × desenho com `object-fit: cover`) resolve, nos experimentos novos, o desalinhamento que a Dissecação tem (D16); `useHandCamera` só roda a rede neural em quadro novo da câmera.
  - 20 verificações automáticas novas (46 no total), sem câmera nem GPU.
- **Atributo de qualidade**: Reusabilidade, Testabilidade, Usabilidade (interação natural), Eficiência (inferência só em quadro novo).
- **Como usar**: amplia o argumento de interação natural (C4) de um experimento para três e mostra o caminho de evolução "experimento isolado → módulo comum". A tabela de validação do Boyle é uma boa evidência de que a simulação é **fisicamente correta**, não só visual.

### A10 — App instalável de desktop (Tauri) sem tocar no código da aplicação (21/10/2026)

- **Mudança**: criado o app de desktop com Tauri 2 (`frontend/src-tauri/`), que exibe o mesmo build do site no WebView do sistema; workflow `instaladores.yml` para Windows e Linux. Estratégia completa (Tauri no desktop, TWA no Android, PWA para offline) em `docs/DISTRIBUICAO.md`.
- **Evidência**:
  - **0 arquivos alterados em `frontend/src/`**; a única diferença site × app é de configuração (`base` e HTTPS no `vite.config.ts`, ativados por `TAURI_ENV_PLATFORM`).
  - Código específico da plataforma: **43 linhas de Rust** (31 sem comentários; abrir a janela + liberar a câmera, inclusive no WebKitGTK do Linux) + 42 de `tauri.conf.json` + 30 de `Cargo.toml`.
  - Instaladores Windows: **1,4 MB** (NSIS) e **1,9 MB** (MSI); executável com o site embutido: 3,3 MB. Museu Virtual testado e funcionando no app.
  - Decisões anteriores reaproveitadas: roteamento por hash (A1) dispensou rotas no app; processamento 100% local tornou o offline um problema de empacotamento.
- **Atributo de qualidade**: Portabilidade (adaptabilidade, instalabilidade).
- **Como usar**: mostra que a independência de plataforma não vale só para os hospedeiros de apresentação (página, sala, AR), mas também para o **ambiente de execução**. A matriz de funcionalidades por plataforma (seção 3 de `docs/DISTRIBUICAO.md`) é candidata a quadro nos Resultados; a explicação de por que o WebXR não pode ser empacotado justifica a estratégia mista.

### A11 — Offline (PWA) e app Android (TWA) sem tocar nos experimentos (23/10/2026)

- **Mudança**: MediaPipe (WASM + modelo) e fontes passaram a ser servidos pelo próprio site (`scripts/mediapipe-assets.mjs`, `@fontsource`); PWA com `vite-plugin-pwa` (precache do build inteiro); `core/offline.ts` e `core/platform.ts`; campo `xr` no registro para a Galeria do app de desktop marcar RA/RV como "só no site"; APK Android do tipo TWA (`android/`, Bubblewrap); instaladores em português. Detalhes nas seções 5 e 6 de `docs/DISTRIBUICAO.md`.
- **Evidência**:
  - **0 arquivos de experimento alterados**; 6 arquivos de infraestrutura comum (+74/−7 linhas) e 2 novos em `core/`.
  - Os **3** experimentos de webcam ficaram offline trocando **2 constantes** num só módulo (`core/handTracking.ts`), um dividendo direto da centralização da A9.
  - A versão do WASM agora é copiada do pacote instalado: a armadilha "atualizar a versão do pacote e a URL juntas" deixou de existir.
  - Precache: 51 arquivos, ≈ 31,2 MB (30 MB são o MediaPipe). Instaladores Windows: 1,4 → 12,8 MB (NSIS); APK TWA: 1,3 MB (abre o site; o conteúdo vem do service worker).
  - O registro (`registry.ts`), que já era fonte única de Galeria/Museu/Teoria, passou a orientar também a interface por plataforma (campo `xr`).
- **Atributo de qualidade**: Portabilidade (adaptabilidade, instalabilidade), Disponibilidade (offline).
- **Como usar**: completa a A10. O mesmo build roda em **cinco ambientes**: site, PWA instalada, Windows, Linux e Android. As únicas diferenças são de configuração (`vite.config.ts`) ou do motor da plataforma (WebXR). O "custo" (≈ 31 MB no 1º acesso) é uma troca consciente, boa para a discussão.

### A12 — Controle de videogame no Museu Virtual e na RV: terceira fonte de entrada (06/11/2026)

- **Mudança**: `core/gamepad.ts` (140 linhas, sem three nem react) lê a Gamepad API e entrega um quadro de entrada (analógicos com zona morta radial, botões apertados/recém-apertados/recém-soltos), com o mapeamento isolado em `GamepadLayout`. No Museu Virtual, o controle soma ao mesmo vetor de movimento do teclado e do joystick de toque, e o analógico direito usa o mesmo giro de câmera do toque (`rotateLook`). Nas variantes VR do Bohr e do DNA, `core/gamepadRig.ts` (73 linhas) põe a câmera num rig que o controle move durante a sessão WebXR, para quem tem só o celular e um gamepad.
- **Evidência**:
  - `museum/layout.ts` (colisão, portas) e os modelos `BohrModel/` e `DnaHelix/` **não foram alterados**: o domínio continua indiferente à origem da entrada.
  - 6 arquivos alterados (+115/−17), 2 novos em `core/`. As duas variantes VR ganharam locomoção com cerca de 15 linhas cada, reaproveitando o mesmo rig.
  - É a **terceira** ocorrência da abstração de entrada (A5: teclado e toque → vetor; Dissecação: MediaPipe e mouse → `PinchState`). Zona morta e detecção de bordas são funções puras (`applyDeadzone`, `readFrame`), testáveis sem navegador.
- **Atributo de qualidade**: Modificabilidade (nova entrada sem tocar no domínio), Portabilidade (controle no PC e no Android), Testabilidade.
  - Ajustar os parâmetros das salas pelo controle (Start abre o HUD, D-pad navega) foi resolvido no hospedeiro: como os controles são **dados** (`ControlDef`), uma função `stepControl` de 10 linhas serve a todas as salas, e **nenhum `sala.ts` foi alterado**.
- **Como usar**: reforça o argumento da A5, com uma terceira fonte de entrada, e mostra o retorno de os controles serem declarativos (a mesma descrição agora serve a mouse, toque e D-pad). Verificado pelo autor com o Machenike G5 Pro no Museu Virtual e na RV do celular (09/11/2026).

### Nota de nomenclatura (06/10/2026)

Os nomes de trabalho usados durante o desenvolvimento foram substituídos por termos mais precisos, em todo o código, na interface e nesta documentação (as entradas acima já usam os nomes novos):

| Nome antigo | Nome atual | No código | Motivo |
|---|---|---|---|
| Modo Imersivo | **Museu Virtual** (o espaço se chama **Museu CLARA.js**) | pasta `src/museum/`, rota `#/museu`, componente `VirtualMuseum` | No computador e no celular a experiência é **realidade virtual não imersiva** (*desktop VR*), então "imersivo" era incorreto; e com o headset (etapa 4) ela passará a ser imersiva. O nome descreve **o lugar**, não o grau de imersão, que depende do dispositivo |
| versão joguinho / `jogo.ts` | **sala interativa** / `sala.ts` | tipo `InteractiveRoom` (`museum/interactiveRoom.ts`), export `sala` | Termo descritivo, coerente com o vocabulário de museu e com o que o código já chamava de sala (`buildRoom`, `RoomSpec`) |
| Modo Normal | **Galeria** | modo `'gallery'` em `ModeSelect.tsx` | Descreve o que a tela é (cards de experimentos) |

Termos técnicos do WebXR (`immersive-vr`, `immersive-ar`) e os conceitos de **realidade virtual imersiva / não imersiva** não mudam: são categorias da literatura, não nomes do produto.

**Sugestão de definição para a monografia** (o termo precisa ser definido no texto, porque no uso comum "museu" remete a arte e acervo histórico):

> *Neste trabalho, **Museu Virtual** designa um ambiente virtual 3D navegável em primeira pessoa, organizado como um edifício de exposições, no qual cada sala abriga um experimento científico interativo (**sala interativa**). O termo segue o uso de "museu virtual" na literatura de realidade virtual e de museus de ciência — um espaço de exposição e experimentação, não necessariamente de acervo histórico ou artístico. Quanto à classificação no contínuo de Milgram e Kishino (1994), o Museu Virtual é realidade virtual **não imersiva** quando acessado por tela (computador ou celular) e **imersiva** quando acessado por headset.*

Vale citar exemplos de museus de ciência interativos (como os *science centers*, cujo foco é experimentar, e não contemplar acervo) para reforçar que a palavra não é usada no sentido de museu de arte.

---

## 22. Evolução do contrato de cena: de "dona de tudo" a "montável"

> **Status: IMPLEMENTADA para os 4 experimentos fáceis (06/10/2026).** Proposta escrita em 06/10/2026 e implementada no mesmo dia para Pêndulo, Geometria Molecular, DNA e Bohr, com as opções **D** (controles em camadas) e **2** (troca de fase com transição). As subseções 22.1–22.6 guardam a proposta como foi escrita; **22.7** registra a decisão final, o que mudou em relação à proposta e as alternativas descartadas; **22.8** detalha cada experimento. Este registro segue o formato de um *Architecture Decision Record* (ADR): contexto, decisão, consequências.

### 22.1 Como era (contrato atual)

Cada `scene.ts` é uma **aplicação 3D completa e autossuficiente**. A fábrica `create*Scene` cria e controla tudo:

```ts
export function createPendulumScene(canvas, config, bg): PendulumScene {
  const renderer = new THREE.WebGLRenderer({ canvas });     // ① infraestrutura
  const scene    = new THREE.Scene();                        //   (igual em todos
  const camera   = new THREE.PerspectiveCamera(...);         //    os experimentos)
  const controls = new OrbitControls(camera, canvas);
  scene.add(new THREE.AmbientLight(...), new THREE.DirectionalLight(...));
  new ResizeObserver(...);

  const pivotGroup = new THREE.Group(); /* haste, massa */   // ② conteúdo do experimento
  let state = { theta, omega };

  requestAnimationFrame(function animate(t) {                // ③ laço próprio
    state = stepPendulum(state, cfg, dt);                    //   (física + render)
    renderer.render(scene, camera);
  });
  return { update(cfg) {...}, dispose() {...} };
}
```

Isso funcionou bem enquanto **o único lugar onde um experimento aparecia era a sua própria página**: um experimento = um canvas = um renderer = uma câmera.

### 22.2 Por que mudar

O Museu Virtual (seção 21, A4/A5) criou um **segundo hospedeiro**: um mundo 3D que já tem renderer, câmera (a do jogador), luzes, laço e entrada (teclado, toque e, no futuro, controles VR). Para um experimento aparecer **dentro** desse mundo, numa sala atrás da porta, sem quebrar a imersão (nota conceitual em A5), o contrato atual não serve:

| O que o `scene.ts` atual faz | Problema dentro do museu |
|---|---|
| Cria o próprio `WebGLRenderer` | Dois renderers não desenham no mesmo mundo |
| Cria a própria câmera + `OrbitControls` | A câmera é a do jogador; OrbitControls brigaria com WASD/joystick |
| Adiciona luzes globais e cor de fundo | Mudaria a iluminação/fundo do museu inteiro |
| Roda o próprio laço (`requestAnimationFrame`) | Dois laços desincronizados; no VR só o laço da sessão XR vale |
| Usa sliders HTML do `index.tsx` | Não há HTML dentro do mundo 3D (nem no óculos) |

Ou seja: o contrato atual mistura **infraestrutura** (①, ③), que pertence a quem hospeda, com **conteúdo** (②), que pertence ao experimento. Enquanto só havia um hospedeiro, essa mistura não custava nada; com dois, ela impede o reuso.

### 22.3 Como muda (decisão proposta)

Separar as duas responsabilidades em dois papéis:

- **Módulo montável** (experimento): só sabe montar seus objetos num grupo, avançar no tempo e reagir a parâmetros. Não cria renderer, câmera, luzes globais, laço nem UI.
- **Hospedeiro** (página ou museu): fornece renderer, câmera, iluminação, laço, entrada e a forma de exibir os controles.

```ts
// Contrato novo (proposta) — src/core/mountable.ts
export interface MountContext {
  root: THREE.Group;         // onde o experimento coloca seus objetos (o hospedeiro posiciona/escala o grupo)
}

export interface ControlDef {  // descrição DECLARATIVA de um controle; cada hospedeiro desenha do seu jeito
  id: string;
  label: string;
  kind: 'range' | 'select' | 'action';
  min?: number; max?: number; step?: number; unit?: string;
  options?: { value: string; label: string }[];
}

export interface MountedExperiment<Config> {
  update(config: Config): void;  // igual ao contrato atual
  tick(dt: number): void;        // o HOSPEDEIRO chama a cada frame (dt já limitado)
  dispose(): void;               // libera só o que o experimento montou
}

export interface MountableExperiment<Config> {
  defaults: Config;
  controls: ControlDef[];
  extent: number;                // raio aproximado em unidades próprias → o hospedeiro calcula a escala para caber na sala
  mount(ctx: MountContext, config: Config): MountedExperiment<Config>;
}
```

E o contrato antigo **continua existindo**, agora implementado em cima do novo. A página vira só mais um hospedeiro:

```ts
// scene.ts do Pêndulo depois da migração (esboço)
export const pendulum: MountableExperiment<PendulumSceneConfig> = {
  defaults: { L: 1.5, g: 9.8, theta0: Math.PI / 4 },
  controls: [
    { id: 'L', label: 'Comprimento', kind: 'range', min: 0.5, max: 3, step: 0.1, unit: 'm' },
    /* g, theta0 … */
  ],
  extent: 3.5,
  mount({ root }, config) {
    /* cria pivô, haste, massa dentro de root */
    return {
      tick(dt)     { state = stepPendulum(state, cfg, dt); pivotGroup.rotation.z = -state.theta; },
      update(cfg)  { /* reconstrói haste, reinicia estado */ },
      dispose()    { /* geometrias e materiais do pêndulo */ },
    };
  },
};

// Mesma assinatura de antes → index.tsx NÃO muda.
export function createPendulumScene(canvas, config, bg) {
  return hostInPage(canvas, pendulum, config, { bg, camera: [0, -0.5, 8], target: [0, -1.5, 0] });
}
```

`hostInPage` (em `src/core/`) concentra o que hoje está repetido em todo `scene.ts`: renderer, câmera, OrbitControls, luzes, resize, laço com `dt` limitado, chamando `tick(dt)` e `renderer.render`. O museu terá o seu equivalente, `hostInRoom`, que coloca o `root` numa sala, escala pelo `extent` e desenha os `controls` como um painel 3D com botões (+/−, anterior/próximo) acionados por raycast (mira, toque ou controle VR).

```mermaid
flowchart TB
  subgraph Experimento["Módulo montável (por experimento)"]
    P[physics.ts<br/>domínio puro] --> M[mount / tick / update / dispose<br/>+ controls declarativos]
  end
  M --> HP[hostInPage<br/>renderer + câmera + OrbitControls<br/>sliders HTML]
  M --> HR[hostInRoom<br/>sala no museu<br/>painel 3D de controles]
  HP --> PG[Página do experimento<br/>index.tsx inalterado]
  HR --> MU[Museu — desktop / celular / VR]
```

### 22.4 Estratégia de migração

Migração **incremental** (padrão *Strangler Fig*): os dois contratos convivem; cada experimento migra quando fizer sentido, e os que não combinam com o museu podem nunca migrar.

1. Criar `src/core/mountable.ts` (tipos) e `src/core/hostInPage.ts`.
2. **Piloto: Pêndulo.** Migrar e verificar que a página continua idêntica (`index.tsx` e `physics.ts` sem nenhuma linha alterada).
3. Criar `hostInRoom` + painel 3D de controles a partir de `ControlDef`, e uma sala do museu para o Pêndulo.
4. Migrar os outros fáceis: Geometria Molecular, DNA e Bohr.
5. Depois, levar o museu para o VR (etapa 4 do Museu Virtual): como as salas já vivem no mesmo mundo, entrar num experimento **não encerra a sessão XR**.

| Experimento | Candidato? | Motivo | Status |
|---|---|---|---|
| Pêndulo | ✔ piloto | pequeno (≤ 3,5 m), 3 controles, física com estado (exercita `tick`) | ✅ implementado (06/10) |
| Geometria Molecular | ✔ | estático, 1 controle (select) | ✅ implementado (06/10) |
| DNA | ✔ | geometria fixa + rotação, 1 controle | ✅ implementado (06/10) |
| Bohr | ✔ | as variantes XR/AR já trocam elemento sem HTML (gatilho + painel `CanvasTexture`) | ✅ implementado (06/10) |
| Ondas | ◐ | cabe na sala (10 × 6 m), 3 controles contínuos | depois |
| Sistema Solar | ◐ | daria um "planetário"; escala precisa ser repensada | depois |
| Projétil | ✘ por ora | alcance de centenas de metros e câmera que se reenquadra sozinha | — |
| Dissecação | ✘ | depende de webcam + câmera fixa voltada para a tela | — |
| Variantes `xr*`/`ar*` | — | ficam redundantes quando as salas funcionarem no VR | avaliar remoção |

### 22.5 Consequências

**Positivas**
- O mesmo experimento existe em dois hospedeiros (página e museu) e, por consequência, em três dispositivos (desktop, celular, VR) **sem duplicar código** — hoje Bohr e DNA têm três `scene.ts` cada.
- O código de infraestrutura repetido em cada `scene.ts` vai para um lugar só (`hostInPage`), atacando o item 2 do roteiro (seção 18).
- `tick(dt)` recebido de fora torna fácil, no futuro, testar ou acelerar uma simulação sem renderizar.
- Os controles viram **dados** (`ControlDef`), não JSX: o mesmo dado gera slider HTML ou botão 3D.

**Negativas / riscos**
- Período de transição com dois contratos convivendo (exige disciplina e documentação — esta seção).
- Experimentos que hoje adicionam luzes globais ou dependem da própria câmera precisam ser adaptados (luzes passam a ser locais ao `root`, com alcance limitado).
- O painel de controles 3D é código novo e é onde está o maior esforço da etapa (UI dentro do mundo, legível em tela e no óculos).

### 22.6 Como medir (para o diário)

Ao migrar cada experimento, registrar na seção 21:
- linhas do `scene.ts` antes × depois, e quantas foram para `hostInPage` (compartilhadas);
- arquivos tocados fora do `scene.ts` (meta: **zero** em `physics.ts` e `index.tsx`);
- se a página ficou visualmente idêntica (captura antes/depois);
- quantos hospedeiros/dispositivos o experimento passou a suportar.

Boa figura para a monografia: o diagrama da 22.3 lado a lado com um "antes" em que cada experimento é uma caixa fechada contendo renderer + câmera + laço + conteúdo.

### 22.7 Decisão final e implementação (06/10/2026)

**Opções escolhidas**

| Problema | Opção escolhida | Alternativas descartadas e por quê |
|---|---|---|
| Controles dentro do mundo 3D | **D — camadas**: camada A (HUD gerado de `ControlDef`, automático para todo experimento) + camada B (interações diretas opcionais, declaradas no `sala.ts`) | **A sozinha** (só HUD): barata, mas sem interação direta com o mundo. **B sozinha** (só controles diegéticos): exigiria código sob medida em todo experimento. **C** (painel 3D genérico): só é necessário no VR; adiada para a etapa 4 — a mesma lista de `ControlDef` vai gerá-lo |
| Como entrar nas salas | **2 — troca de fase com transição**: a tela escurece (0,35 s), a sala substitui o salão no MESMO renderer e na MESMA cena, e clareia | **1** (sala anexa física): o `layout.ts` teria de reservar espaço atrás das paredes, salas de tamanhos diferentes se sobreporiam e tudo ficaria carregado ao mesmo tempo. **3** (vitrine no salão): só serve para objetos pequenos. **4** (portal renderizado): custo de renderizar a cena duas vezes, exagerado para o escopo |

**Arquivos criados**

| Arquivo | Linhas | Papel |
|---|---|---|
| `src/core/mountable.ts` | 35 | Contrato `MountableExperiment` / `MountedExperiment` |
| `src/core/hostInPage.ts` | 102 | Hospedeiro "página": renderer, câmera, OrbitControls, luzes, resize, laço |
| `src/core/controls.ts` | 34 | `ControlDef` declarativo (range/select) |
| `src/museum/interactiveRoom.ts` | 48 | Contrato da sala interativa (`InteractiveRoom`, `RoomSpec`, `RoomInteraction`) |
| `src/museum/levels.ts` | 93 | Fases: `buildHall` e `buildRoom` com a mesma interface `Level` |
| `src/museum/builders.ts` | 171 | Chão/paredes/portas/placas compartilhados por salão e salas (extraído do antigo `scene.ts`) |
| `src/museum/ControlsHud.tsx` | 87 | HUD genérico: desenha qualquer lista de `ControlDef` |
| `<experimento>/sala.ts` × 4 | 29–71 | Regras de cada sala (ver 22.8) |
| `chemistry/BohrModel/elements.ts` | 31 | Tabela única de elementos (efeito colateral, ver 22.8) |

**O que mudou em relação à proposta (22.3)** — registro honesto dos desvios:

1. **`ControlDef` saiu do experimento e foi para o `sala.ts`.** A proposta punha `controls` no `MountableExperiment`. Na prática, os controles da sala nem sempre são os da página (o Bohr da página aceita distribuição eletrônica digitada; a sala só oferece a lista de elementos) e a página continua com seus sliders em JSX. Então os controles são uma **regra da sala**, não do experimento — o que confirma a intuição de "um arquivo com as regras do mundo 3D por experimento". O `MountableExperiment` ficou menor: só `mount`.
2. **`extent` (escala automática) foi trocado por `place` + `scale` explícitos no `RoomSpec`.** Cada sala tem uma composição própria (pêndulo pendurado alto, molécula sobre pedestal, átomo acima da cabeça); um único "raio" não decide isso bem.
3. **Regra nova sobre luzes**: *luz que faz parte do fenômeno é do experimento; luz de ambiente é do hospedeiro*. Surgiu no Bohr (a luz pontual do núcleo foi para dentro do `mount`).
4. **Regra nova sobre o passo de tempo**: garantias de precisão que dependiam do laço próprio passam a morar no experimento (o Pêndulo subdivide `dt` > 20 ms dentro do `tick`). Surgiu no Pêndulo.

**Descoberta automática.** O museu encontra as salas com `import.meta.glob('../simulations/**/sala.ts')` e **só cria portas para experimentos que têm `sala.ts`** (decisão de 06/10/2026, ver A7; na primeira versão as demais portas abriam a página e as de sala eram marcadas com ★). O caminho "porta → página" continua no `scene.ts` como alternativa, mas nenhuma porta o usa hoje. Nenhuma lista para manter — o mesmo mecanismo do `teoria.md`.

**Verificação.** Teste de fumaça executado no Node, sem navegador nem GPU (o `<canvas>` 2D das placas foi simulado), com 14 verificações, todas aprovadas:
- os 4 experimentos montam, recebem `tick`, aceitam `update` com os valores extremos de cada controle e deixam o `root` vazio após `dispose`;
- o Pêndulo dá o mesmo ângulo com `tick(0,1)` e com 5 × `tick(0,02)` (subpasso correto);
- a interação "pegar a massa": a mira na massa é alvo e ao lado não é; arrastar até 30° segura em 30,00° com a física pausada; ao soltar, após 0,5 s está em 8,73° (teórico para L = 1,5 m: 30°·cos(2π·0,5/2,46) ≈ 8,7°);
- as 4 salas montam, detectam a porta de saída, colidem nas paredes e liberam os recursos;
- o salão continua montando a partir do registro.

Não verificado automaticamente: a renderização em si (aparência, transição, HUD) — exige teste manual no navegador.

### 22.8 Especificidades de cada experimento e impacto na arquitetura

| | Pêndulo | Geometria Molecular | DNA | Bohr |
|---|---|---|---|---|
| `scene.ts` antes → depois | 142 → 146 | 151 → 123 | 160 → 133 | 257 → 239 |
| `physics.ts` alterado? | não | não | não | não |
| `index.tsx` alterado? | não | não | não | sim (−24/+1: importa `elements.ts`) |
| `sala.ts` | 71 linhas | 35 linhas | 29 linhas | 40 linhas |
| Sala | 8 × 9 m, pé-direito 4,8 m | 8 × 8 m | 8 × 8 m, pé-direito 5 m | 10 × 10 m, pé-direito 5 m |
| Posição / escala | pivô a 3,8 m; escala 1 | pedestal; centro a 2 m; escala 0,5; giro 0,4 rad/s | centro a 2,4 m; escala 0,3; colisão 0,7 m | núcleo a 2,3 m; escala 0,1 (camada 4 = 3,2 m) |
| Camada A (HUD) | L, g, θ₀ | molécula (select) | pares de base, rotação | elemento (select), velocidade |
| Camada B | **pegar e soltar a massa** | — | — | — |
| O que exercitou da arquitetura | `tick` com estado físico; `RoomInteraction`; métodos extras no `Mounted` (`grab`/`release`) | caso mínimo (só dados); `spin` e `pedestal` | `obstacleRadius`; luzes padrão do `hostInPage` servem sem configuração | controles da sala ≠ da página (`toConfig` traduz); luz do fenômeno no experimento |
| Efeitos colaterais | subpasso de integração passou para o `tick` (independe do hospedeiro) | `dispose` simplificado (sumiu um `scene.traverse` redundante) | — | **D2 e D19 resolvidos**; tabela de elementos unificada (−68/+7 em 3 arquivos, parte de D3) |

Somando os quatro: os `scene.ts` foram de 710 para 641 linhas (−69), mesmo com o Pêndulo ganhando funcionalidade nova, e 102 linhas de infraestrutura passaram a existir **uma vez** em `hostInPage.ts`. Os detalhes de cada sala estão na seção "Sala interativa" do `README.md` de cada experimento (visível no site, aba "Como foi feito").

---

## 23. Realidade aumentada: o terceiro hospedeiro (`hostInAR`)

> **Status: IMPLEMENTADO (06/10/2026)** para Bohr, DNA e Geometria Molecular. Não testado em aparelho até esta data — o teste real exige um celular Android com ARCore (ver 23.6).

### 23.1 Contexto: como era

As variantes `arBohrModel` e `arDnaHelix` eram cenas completas e independentes (`scene.ts` + `index.tsx`, 674 linhas no total), cópias das cenas desktop com outra escala. Problemas de usabilidade e de arquitetura:

| Problema | Consequência |
|---|---|
| Objeto fixo em coordenadas (1,5 m à frente de onde o celular estava ao iniciar) | O usuário precisava **procurar** o objeto; ele podia aparecer dentro de uma mesa ou parede |
| Sem gestos | Não dava para mover, redimensionar nem girar |
| `ARButton` sem `dom-overlay` (D4) | Os controles HTML sumiam durante a sessão |
| Matemática da hélice e tabela de elementos duplicadas (D3) | Toda mudança no experimento precisava ser repetida no AR |
| DNA centrado no nível do chão (D22) | Metade da hélice ficava "enterrada" |

### 23.2 Decisão

Seguindo o padrão consagrado por apps comerciais de AR (ARCore/ARKit: "posicionar produto na sala"), decidido em conjunto com o autor:

- **Tocar para posicionar** sobre uma superfície detectada (retícula + hit-test);
- **Gestos**: arrastar (mover), pinça (escala de 20% a 500%), girar com dois dedos, botão Reposicionar;
- **Ajustes ⚙** durante a sessão (o mesmo painel do Museu Virtual);
- **Arquitetura**: em vez de corrigir as duas cenas copiadas, criar um **hospedeiro AR genérico** para experimentos montáveis (seção 22). Alternativa descartada: adicionar hit-test e gestos nas cenas existentes — mais rápido, mas manteria (e aumentaria) a duplicação.
- **Experimentos**: Bohr e DNA (que já tinham AR) e Geometria Molecular (que passou a ter).

### 23.3 Como funciona

```mermaid
stateDiagram-v2
  [*] --> preview
  preview --> searching: Iniciar AR (requestSession immersive-ar)
  searching --> ready: hit-test encontrou superfície (retícula visível)
  ready --> searching: perdeu a superfície
  ready --> placed: toque na tela (evento select)
  placed --> ready: Reposicionar
  searching --> preview: Sair / fim da sessão
  ready --> preview: Sair / fim da sessão
  placed --> preview: Sair / fim da sessão
```

| Peça | Arquivo | Papel |
|---|---|---|
| `hostInAR` | `src/ar/scene.ts` (297 linhas) | Renderer com alpha; sessão `immersive-ar` com `requiredFeatures: ['hit-test']` e `optionalFeatures: ['dom-overlay']`; retícula; posicionamento; conversão de gestos em transformações; prévia com OrbitControls fora da sessão |
| Matemática dos gestos | `src/ar/gestures.ts` (43 linhas) | Pura: dois segmentos de dedos → fator de escala (razão dos comprimentos) e rotação (diferença dos ângulos, normalizada para (−π, π]); pixels → NDC |
| Página genérica | `src/ar/index.tsx` (245 linhas) | Prévia, botão "Iniciar AR" ou aviso de incompatibilidade, sobreposição da sessão (dom-overlay) com status, camada de gestos e botões |
| Definição por experimento | `<variante AR>/ar.ts` (~20 linhas cada) | `experiment`, `controls`/`toConfig` (reaproveitados do `sala.ts`), `scale`, `lift`, `previewDistance` |
| Painel de ajustes | `src/components/ControlsHud/` | Movido de `museum/` para `components/`: agora é compartilhado entre Museu Virtual e AR |

Detalhes técnicos que valem para a monografia:

- **Hit-test** (*WebXR Hit Test Module*): a cada quadro, `frame.getHitTestResults(source)` devolve onde um raio que sai do centro da tela (espaço `viewer`) encosta numa superfície real detectada pelo ARCore. A pose do primeiro resultado posiciona a retícula.
- **Posicionamento**: tocar a tela gera o evento `select` do WebXR; com a retícula visível, a âncora do objeto vai para a posição dela e gira para ficar **de frente para o usuário** (`atan2` entre câmera e ponto).
- **dom-overlay** (*WebXR DOM Overlay Module*): o `<div>` de sobreposição continua visível e recebe toques durante a sessão. Problema resolvido: um toque no HTML também dispara `select`; o evento `beforexrselect` é cancelado nos botões (sempre) e na camada de gestos (depois de posicionado), para que tocar um botão ou fazer uma pinça não reposicione o objeto.
- **Arrastar**: o toque vira um raio pela câmera do celular (`renderer.xr.getCamera()`), intersectado com o **plano horizontal da superfície**; um deslocamento calculado no início evita que o objeto "pule" para baixo do dedo.
- **Pinça + giro simultâneos**: os dois saem do mesmo par de dedos (`twoFingerTransform`), como nos apps comerciais. Ao soltar um dos dedos, o arrasto continua com o outro.
- **Altura acompanha a escala**: `root.position.y = lift × escala`, para o objeto continuar apoiado ao ser aumentado.
- **Detecção de suporte**: `navigator.xr.isSessionSupported('immersive-ar')`; sem suporte (iPhone, desktop), a página mostra a prévia 3D e um aviso.

### 23.4 Consequências

| Métrica | Antes | Depois |
|---|---|---|
| Experimentos com AR | 2 | **3** |
| Código específico de AR por experimento | 352 (Bohr) e 322 (DNA) linhas | **20–21 linhas** (`ar.ts`) |
| Código AR total | 674 linhas (2 cenas copiadas) | 604 linhas genéricas (`src/ar/`) + 61 de definições = 665 |
| Posicionar / mover / escalar / girar | não / não / não / não | sim / sim / sim / sim |
| Ajustes durante a sessão | não (HTML sumia) | sim (dom-overlay) |
| Custo de dar AR a mais um experimento montável | uma nova cena inteira (~300 linhas) | ~20 linhas + 1 entrada no registro + 1 linha no `App.tsx` |

O volume de código ficou praticamente igual (674 → 665), mas passou de **específico** para **genérico**: com a mesma quantidade de linhas, saiu-se de 2 experimentos AR sem nenhuma interação para 3 com posicionamento e gestos, e o quarto custa 20 linhas.

Débitos resolvidos: **D4** (controles sumiam no AR), **D22** (no AR; a variante VR do DNA continua com o problema) e a parte AR do **D3**. **D17** deixa de valer para o AR (o toque é sempre o controle 0).

### 23.5 Os três hospedeiros

Com o AR, o contrato montável (seção 22) passa a ter três hospedeiros reais — a demonstração mais completa da tese de que o domínio é independente da forma de apresentação:

```mermaid
flowchart LR
  subgraph Exp["Experimento montável (ex.: Bohr)"]
    P[physics.ts] --> S["scene.ts → mount / tick / update / dispose"]
  end
  S --> H1["hostInPage<br/>página (desktop/celular)"]
  S --> H2["sala interativa<br/>Museu Virtual (desktop/celular; VR planejado)"]
  S --> H3["hostInAR<br/>realidade aumentada (Android)"]
  C["sala.ts → controls + toConfig"] --> H2
  C --> H3
```

| Experimento | Página | Sala interativa | AR |
|---|---|---|---|
| Pêndulo | ✔ | ✔ | — |
| Geometria Molecular | ✔ | ✔ | ✔ (novo) |
| DNA | ✔ | ✔ | ✔ |
| Bohr | ✔ | ✔ | ✔ |

### 23.6 Verificação e limites

- **Testado automaticamente (Node, sem GPU)**, 12 verificações: pinça abrindo (×2) e fechando (×0,5); giro de 90°; giro pequeno perto de ±180° sem virar "quase uma volta"; pinça e giro simultâneos; dedos colados sem divisão por zero; normalização de ângulo; conversão de pixels para NDC; limites de escala; e as três definições montando o experimento num tamanho de mesa (Bohr ~65 cm, DNA ~54 cm de altura, molécula ~20 cm).
- **Não testado**: a sessão AR em si (hit-test, retícula, posicionamento, gestos no aparelho). Exige celular Android com ARCore + Chrome. Roteiro sugerido: abrir pelo GitHub Pages (HTTPS válido) e testar em mesa com textura e boa luz.
- **Limitações conhecidas**: só Android/Chrome (o Safari do iPhone não implementa `immersive-ar`); sem âncoras do WebXR (pode haver leve deriva em sessões longas); sem estimativa de luz do ambiente; `lift` fixo por experimento.
